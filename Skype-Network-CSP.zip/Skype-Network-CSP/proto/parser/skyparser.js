'use strict';

const functions = require('../../functions/functions.js');
const skycrypto = require('../../crypto/skycrypto.js');
const skyobjects = require('../objects/skyobjects.js');
const logger = require('../../logger/logger.js');
const varint = require('../utils/varint.js');

const MAX_AUTH_BLOB_SIZE = 64 * 1024;
const MAX_TLS_RECORD_SIZE = 64 * 1024;
const MAX_41_OBJECTS = 256;
const MAX_41_TYPE6_ITEMS = 4096;
const MAX_41_NESTING_DEPTH = 8;

function validate_x192(x192) {
    if (!Buffer.isBuffer(x192) || x192.length !== 192 || x192[0] !== 0x01) {
        return false;
    };

    const reference_block = x192.subarray(24, 48);

    if (!x192.subarray(1, 24).equals(reference_block.subarray(1))) {
        return false;
    };

    for (let offset = 48; offset < 192; offset += 24) {
        if (!x192.subarray(offset, offset + 24).equals(reference_block)) {
            return false;
        };
    };

    return true;
};

function read_41_varint(data, state) {
    const decoded = varint.read_7bit_uint(data, state.offset);
    state.offset = decoded.offset;
    return decoded.value;
};

function read_41_bytes(data, state, length) {
    if (!Number.isInteger(length) || length < 0 || state.offset + length > data.length) {
        throw new RangeError('Incomplete 41 byte field');
    };

    const value = Buffer.from(data.subarray(state.offset, state.offset + length));
    state.offset += length;
    return value;
};

function parse_41_sequence(data, state, depth = 0) {
    if (depth > MAX_41_NESTING_DEPTH) {
        throw new RangeError('41 nesting limit exceeded');
    };

    if (state.offset >= data.length || data[state.offset++] !== 0x41) {
        throw new Error('Expected 41 sequence');
    };

    const object_count = read_41_varint(data, state);

    if (object_count > MAX_41_OBJECTS) {
        throw new RangeError('41 object count limit exceeded');
    };

    const fields = [];

    for (let index = 0; index < object_count; index++) {
        if (state.offset >= data.length) {
            throw new RangeError('Incomplete 41 field');
        };

        const type = data[state.offset++];
        const id = read_41_varint(data, state);
        const field = { type, id, value: null };

        switch (type) {
            case 0:
                field.value = read_41_varint(data, state);
                break;

            case 1:
                field.value = read_41_bytes(data, state, 8);
                break;

            case 2:
                field.value = read_41_bytes(data, state, 6);
                break;

            case 3: {
                const string_end = data.indexOf(0x00, state.offset);

                if (string_end === -1) {
                    throw new RangeError('Unterminated 41 string');
                };

                field.value = data.subarray(state.offset, string_end).toString('utf8');
                state.offset = string_end + 1;
                break;
            };

            case 4: {
                const length = read_41_varint(data, state);
                field.value = read_41_bytes(data, state, length);
                break;
            };

            case 5:
                field.children = parse_41_sequence(data, state, depth + 1);
                break;

            case 6: {
                const item_count = read_41_varint(data, state);

                if (item_count > MAX_41_TYPE6_ITEMS) {
                    throw new RangeError('41 type-6 item count limit exceeded');
                };

                const values = [];
                for (let item_index = 0; item_index < item_count; item_index++) {
                    values.push(read_41_varint(data, state));
                };

                field.value = values;
                break;
            };

            default:
                throw new Error(`Unsupported 41 field type: ${type}`);
        };

        fields.push(field);
    };

    return fields;
};

function parse_packet_blob(aes_key, data, size = data?.length) {
    if (!Buffer.isBuffer(data)) {
        return { ok: false, error: 'data must be a Buffer' };
    };

    if (!Number.isInteger(size) || size <= 0 || size > data.length || size > MAX_AUTH_BLOB_SIZE) {
        return { ok: false, error: 'invalid 41 blob size' };
    };

    const buffer = data.subarray(0, size);
    const state = { offset: 0 };
    const sequences = [];

    try {
        while (state.offset < buffer.length) {
            sequences.push(parse_41_sequence(buffer, state));
        };
    } catch (error) {
        return { ok: false, error: error.message };
    };

    if (sequences.length === 0) {
        return { ok: false, error: 'empty 41 blob' };
    };

    const account_fields = sequences[0];
    const metadata_fields = sequences[1] || [];
    const all_fields = sequences.flat();

    const find_field = (fields, type, id) =>
        fields.find(field => field.type === type && field.id === id);

    const cmd_field = find_field(account_fields, 0, 0x00);
    const request_id_field = find_field(account_fields, 0, 0x02);
    const username_field = find_field(all_fields, 3, 0x04);
    const password_field = find_field(all_fields, 4, 0x05);
    const public_key_field = find_field(all_fields, 4, 0x21);
    const client_version_field = find_field(all_fields, 3, 0x0D);
    const language_field = find_field(all_fields, 3, 0x36);

    if (!cmd_field || !request_id_field) {
        return { ok: false, error: 'missing command or request ID' };
    };

    const blob = {
        cmd: cmd_field.value,
        requestId: request_id_field.value,
        username: username_field?.value || '',
        password: Buffer.isBuffer(password_field?.value) ? password_field.value.toString('hex') : null,
        publicKey: Buffer.isBuffer(public_key_field?.value) ? public_key_field.value : null,
        clientVersion: client_version_field?.value || '',
        language: language_field?.value || '',
        metadata: metadata_fields,
        sequences
    };

    return {
        ok: true,
        aes_key,
        blob
    };
};

function make_record_iv(record_index) {
    if (!Number.isInteger(record_index) || record_index < 0 || record_index > 0xFFFF) {
        throw new RangeError('Invalid encrypted record index');
    };

    const iv = Buffer.alloc(16, 0);
    iv.writeUInt32BE(record_index * 0x10000, 12);
    return iv;
};

function parse_tls_records(aes_key, data, start_record_index = 0) {
    if (!Buffer.isBuffer(aes_key) || aes_key.length !== 32) {
        return { ok: false, error: 'AES-256 session key required' };
    };

    if (!Buffer.isBuffer(data)) {
        return { ok: false, error: 'TLS record data must be a Buffer' };
    };

    const packets = [];
    let offset = 0;
    let record_index = start_record_index;

    while (offset < data.length) {
        const remaining = data.length - offset;

        if (remaining < 5) {
            break;
        };

        if (data[offset] !== 0x17 || data[offset + 1] !== 0x03 || data[offset + 2] !== 0x01) {
            return {
                ok: false,
                error: `unexpected TLS application record header at offset ${offset}`,
                packets,
                consumed: offset,
                remainder: data.subarray(offset),
                nextRecordIndex: record_index
            };
        };

        const payload_length = data.readUInt16BE(offset + 3);

        if (payload_length < 3 || payload_length > MAX_TLS_RECORD_SIZE) {
            return {
                ok: false,
                error: `invalid TLS application record length: ${payload_length}`,
                packets,
                consumed: offset,
                remainder: data.subarray(offset),
                nextRecordIndex: record_index
            };
        };

        const record_length = 5 + payload_length;

        if (remaining < record_length) {
            break;
        };

        const payload_start = offset + 5;
        const payload_end = offset + record_length;
        const payload = data.subarray(payload_start, payload_end);
        const encrypted_body = payload.subarray(0, payload.length - 2);
        const received_crc = payload.readUInt16LE(payload.length - 2);

        let decrypted_blob;

        try {
            const iv = make_record_iv(record_index);
            decrypted_blob = skycrypto.aes_ctr(aes_key, encrypted_body, iv);
        } catch (error) {
            return {
                ok: false,
                error: `AES-CTR decrypt failed for record ${record_index}: ${error.message}`,
                packets,
                consumed: offset,
                remainder: data.subarray(offset),
                nextRecordIndex: record_index
            };
        };

        if (!Buffer.isBuffer(decrypted_blob)) {
            return {
                ok: false,
                error: `AES-CTR returned no data for record ${record_index}`,
                packets,
                consumed: offset,
                remainder: data.subarray(offset),
                nextRecordIndex: record_index
            };
        };

        const parsed = parse_packet_blob(aes_key, decrypted_blob, decrypted_blob.length);
        logger.info(`[skyparser] decrypted body for ${parsed.blob.cmd}: ${decrypted_blob.toString('hex')}`);

        if (!parsed.ok) {
            return {
                ok: false,
                error: `could not parse decrypted record ${record_index}: ${parsed.error}`,
                packets,
                consumed: offset,
                remainder: data.subarray(offset),
                nextRecordIndex: record_index
            };
        };

        packets.push({
            recordIndex: record_index,
            blob: parsed.blob,
            decryptedLength: decrypted_blob.length,
            receivedCrc: received_crc
        });

        offset += record_length;
        record_index++;
    };

    return {
        ok: true,
        packets,
        consumed: offset,
        remainder: Buffer.from(data.subarray(offset)),
        nextRecordIndex: record_index,
        incomplete: offset !== data.length
    };
};

function parse_tls_packet(data) {
    const time = functions.getTime();

    if (!Buffer.isBuffer(data)) {
        return { ok: false, error: 'login packet must be a Buffer' };
    };

    let offset = 0;

    if (data.length >= 5 && data[0] === 0x16 && data[1] === 0x03 && data[2] === 0x01 && data.readUInt16BE(3) === 0) {
        offset = 5;
    };

    if (data.length - offset < 5) {
        return { ok: true, incomplete: true, handshakeComplete: false, remaining: Buffer.from(data) };
    };

    if (data[offset] !== 0x16 || data[offset + 1] !== 0x03 || data[offset + 2] !== 0x01) {
        return { ok: false, error: 'missing TLS key-exchange record' };
    };

    const handshake_payload_length = data.readUInt16BE(offset + 3);
    const handshake_record_length = 5 + handshake_payload_length;

    if (handshake_payload_length === 0 || handshake_payload_length > MAX_TLS_RECORD_SIZE) {
        return { ok: false, error: `invalid key-exchange record length: ${handshake_payload_length}` };
    };

    if (data.length - offset < handshake_record_length) {
        return { ok: true, incomplete: true, handshakeComplete: false, remaining: Buffer.from(data) };
    };

    const ext_objects = data.subarray(offset + 5, offset + handshake_record_length);

    if (ext_objects.length === 0 || ext_objects[0] !== 0x42) {
        return { ok: false, error: 'key-exchange record does not contain EXT objects' };
    };

    let aes_key;

    try {
        const decoded = skyobjects.unpack_ext_objects(ext_objects);
        if (!decoded) {
            return { ok: false, error: 'failed to decode EXT key-exchange objects' };
        };

        const x192 = skyobjects.unpack_ext_binary(ext_objects, 4, 8);
        if (!Buffer.isBuffer(x192) || x192.length !== 192) {
            return { ok: false, error: 'missing RSA-1536 key-exchange material' };
        };

        const private_key = skycrypto.get_private_key('private_1536', 1536);
        const decrypted_x192 = skycrypto.decrypt_rsa(private_key, x192);

        if (!validate_x192(decrypted_x192)) {
            return { ok: false, error: 'RSA key-exchange material failed validation' };
        };

        aes_key = skycrypto.generate_aes_key(decrypted_x192);
        if (!Buffer.isBuffer(aes_key) || aes_key.length !== 32) {
            return { ok: false, error: 'failed to derive AES session key' };
        };
    } catch (error) {
        logger.error(`${time} failed to parse TLS key exchange: ${error.message}`);
        return { ok: false, error: error.message };
    };

    const records_start = offset + handshake_record_length;
    const records = parse_tls_records(aes_key, data.subarray(records_start), 0);

    if (!records.ok) {
        return {
            ...records,
            aes_key,
            handshakeComplete: true,
            consumed: records_start + (records.consumed || 0),
            remaining: records.remainder || data.subarray(records_start)
        };
    };

    for (const packet of records.packets) {
        const blob = packet.blob;
        logger.info(`${time} [skyparser] cmd=${blob.cmd} requestId=${blob.requestId} username=${blob.username} clientVersion=${blob.clientVersion}`);
    };

    return {
        ok: true,
        aes_key,
        handshakeComplete: true,
        packets: records.packets,
        blob: records.packets[0]?.blob || null,
        nextRecordIndex: records.nextRecordIndex,
        consumed: records.consumed,
        remainder: records.remainder,
        incomplete: records.incomplete
    };
};

module.exports = {
    parse_tls_packet,
    parse_tls_records,
    parse_packet_blob
};