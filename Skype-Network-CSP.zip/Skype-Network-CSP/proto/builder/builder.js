const functions = require('../../functions/functions.js');
const skycrypto = require("../../crypto/skycrypto.js");
const skyobjects = require("../objects/skyobjects.js");
const logger = require("../../logger/logger.js");
const common = require("../common/common.js");
const varint = require('../utils/varint.js');
const crypto = require('crypto');

function build_nack_packet(transId, remote) {
    try {
        const nack_packet = Buffer.alloc(11);

        nack_packet.writeUInt16BE(transId, 0);
        nack_packet[2] = common.PKT_TYPE_NACK;

        const ip_bytes = remote.address.split('.').map(Number);

        for (let i = 0; i < 4; i++) {
            nack_packet[3 + i] = ip_bytes[i];
        };

        const challenge = Math.floor(Math.random() * 0xFFFFFFFF);

        const challenge_bytes = Buffer.alloc(4);
        challenge_bytes.writeUInt32BE(challenge, 0);

        challenge_bytes.copy(nack_packet, 7, 0, 4);
        return nack_packet;
    } catch (error) {
        const time = functions.getTime();
        
        logger.error(`${time} [supernode] failed to send NACK:`, error.message);
        return;
    };
};

function build_probe_ok(transId, supernode_host, client_public_ip, client, requestId) {
    try {
        const id = Buffer.isBuffer(transId)? transId.readUInt16BE(0): Number(transId);

        const reqId = Number(requestId) & 0xFFFF;
        const probe_ok = Buffer.alloc(18);

        probe_ok.writeUInt16BE(id & 0xFFFF, 0);
        probe_ok[2] = common.PKT_TYPE_OBFSUK;

        const iv = crypto.randomBytes(4).readUInt32BE(0);
        probe_ok.writeUInt32BE(iv, 3);

        const encdoded_cmd = (common.CMD_PROBE_OK << 3) | 0x03;
        const body = Buffer.from([0x04, encdoded_cmd, 0x01, (reqId >>> 8) & 0xFF, reqId & 0xFF, 0x42, 0x15]);

        const bodyCrc = skycrypto.calculate_crc32(body, 0xFFFFFFFF);
        probe_ok.writeUInt32BE(bodyCrc, 7);

        const ipBytesLE = (ip) => Buffer.from(ip.split('.').map(Number).reverse());
        const toCrc = Buffer.alloc(12);

        toCrc.set(ipBytesLE(supernode_host), 0);
        toCrc.set(ipBytesLE(client_public_ip), 4);
        toCrc.writeUInt16LE(id, 8);

        const crcValue = skycrypto.calculate_crc32(toCrc, 0xFFFFFFFF);

        const seed = (crcValue ^ iv) >>> 0;
        const ctx = skycrypto.create_rc4_context(seed);

        skycrypto.rc4(body, ctx, false);
        body.copy(probe_ok, 11);

        return probe_ok;
    } catch (error) {
        const time = functions.time();

        logger.error(`${time} [supernode] failed to build ProbeOK: ${error.message}`);
        return null;
    };
};

function build_tcp_handshake(seed, send_rc4) {
    if (!Number.isInteger(seed) || seed < 0 || seed > 0xFFFFFFFF) {
        logger.info(`${time} [supernode] invalid seed`);
        return null;
    };

    if (!send_rc4) {
        logger.info(`${time} [supernode] rc4 context not found`);
        return null;
    };

    const tcp_handshake = Buffer.alloc(14);
    tcp_handshake.writeUInt32BE(seed >>> 0, 0);

    const body = Buffer.from([
        0x00, 0x01,
        0x00, 0x00, 0x00, 0x01,
        0x00, 0x00, 0x00, 0x03
    ]);

    skycrypto.rc4(body, send_rc4, true);
    body.copy(tcp_handshake, 4);

    return tcp_handshake;
};

function build_new_tcp_handshake(seed, send_rc4) {
    const n = crypto.randomInt(4, 49);
    const seq = crypto.randomBytes(2).readUInt16BE(0);

    const tcp_handshake = Buffer.alloc(16 + n);

    tcp_handshake.writeUInt32BE(seed, 0);
    tcp_handshake.writeUInt16BE(seq, 4);

    Buffer.from([
        0x00, 0x00, 0x00, 0x01,
        0x00, 0x00, 0x00, 0x0F
    ]).copy(tcp_handshake, 6);

    tcp_handshake[14] = (n + 1) * 2 + 1;
    tcp_handshake[15] = 0x03;

    skycrypto.rc4(tcp_handshake.subarray(4, 14), send_rc4, true);
    skycrypto.rc4(tcp_handshake.subarray(14), send_rc4, false);

    return tcp_handshake;
};

function build_tcp_accept(seq, requestId, socket, send_rc4) {
    const client_port = socket.remotePort;
    const objects = [
        {
            type: 0,
            id: common.OBJ_ID_STACKVER,
            m: 0x2C,
            n: 0
        },
        {
            type: 0,
            id: common.OBJ_ID_STACKTS,
            m: 0x2FCDB925,
            n: 0
        },
        {
            type: 0,
            id: common.OBJ_ID_PEERLPORT,
            m: client_port,
            n: 0
        },
        {
            type: 2,
            id: common.OBJ_ID_PUBNETADDR,
            m: ipv4ToUInt32(socket.remoteAddress),
            n: client_port
        },
        {
            type: 6,
            id: 0x21,
            data: Buffer.alloc(8)
        }
    ];

    const encoded_objects = skyobjects.pack_ext_objects(objects);

    if (!encoded_objects) {
        return null;
    };

    const header = Buffer.from([
        0x3C,
        (seq >>> 8) & 0xFF,
        seq & 0xFF,
        0x19,
        0xFB,
        0x01,
        (requestId >>> 8) & 0xFF,
        requestId & 0xFF
    ]);

    const tcp_accept = Buffer.concat([header, encoded_objects]);

    skycrypto.rc4(tcp_accept.subarray(0, 3), send_rc4, false);
    skycrypto.rc4(tcp_accept.subarray(3), send_rc4, false);

    return tcp_accept;
};

function build_tcp_netstats(seq, clients_online, send_rc4) {
    const objects = [
        {
            type: 0,
            id: common.OBJ_ID_NBCONNECTED,
            m: clients_online,
            n: 0
        }
    ];

    const encoded_objects = skyobjects.pack_ext_objects(objects);

    if (!encoded_objects) {
        return null;
    };

    const header = Buffer.from([
        0x10,
        (seq >>> 8) & 0xFF,
        seq & 0xFF,
        0x04,
        common.CMD_NETSTATS
    ]);

    const tcp_netstats = Buffer.concat([header, encoded_objects]);

    skycrypto.rc4(tcp_netstats.subarray(0, 2), send_rc4, false);
    skycrypto.rc4(tcp_netstats.subarray(2), send_rc4, false);

    return tcp_netstats;
};

function build_tcp_ack(seq, send_rc4) {
    const tcp_ack = Buffer.from([
        0x07,
        0x01,
        (seq >> 8) & 0xFF,
        seq & 0xFF
    ]);

    const header = Buffer.from(tcp_ack.subarray(0, 2));
    const body = Buffer.from(tcp_ack.subarray(2, 4));

    skycrypto.rc4(header, send_rc4, false);
    skycrypto.rc4(body,   send_rc4, false);

    const encrypted_tcp_ack = Buffer.alloc(4);
    encrypted_tcp_ack.set(header, 0);
    encrypted_tcp_ack.set(body,   2);

    return encrypted_tcp_ack;
};

function ipv4ToUInt32(ip) {
    const normalized = ip.startsWith('::ffff:') ? ip.slice(7) : ip;
    const parts = normalized.split('.').map(Number);

    if (parts.length !== 4 ||parts.some(n => !Number.isInteger(n) || n < 0 || n > 255)) {
        return null;
    };

    return (
        ((parts[0] << 24) >>> 0) |
        (parts[1] << 16) |
        (parts[2] << 8) |
        parts[3]
    ) >>> 0;
};

function write_varint(value) {
    if (!Number.isInteger(value) || value < 0 || value > 0xFFFFFFFF) {
        return null;
    };

    const bytes = [];

    do {
        let byte = value % 128;
        value = Math.floor(value / 128);

        if (value > 0) {
            byte |= 0x80;
        };

        bytes.push(byte);
    } while (value > 0);

    return Buffer.from(bytes);
};

function append_scalar(id, value) {
    return Buffer.concat([
        Buffer.from([0x00]),
        write_varint(id),
        write_varint(value)
    ]);
};

function build_uic_payload(username, clientModulus, expiry = 0x0BBBD6F1, nestedValue = 0x0BD99AF1) {
    if (typeof username !== 'string' || username.length === 0) {
        return null;
    };

    const username_bytes = Buffer.from(username, 'utf8');

    if (username_bytes.length === 0 || username_bytes.length >= 32 || username_bytes.includes(0)) {
        return null;
    };

    if (!Buffer.isBuffer(clientModulus) || clientModulus.length !== 128) {
        return null;
    };

    const parts = [
        Buffer.from([0x41, 0x05]),

        Buffer.from([0x03]),
        write_varint(0x00),
        username_bytes,
        Buffer.from([0x00]),

        append_scalar(3, 0),

        Buffer.from([0x04]),
        write_varint(0x01),
        write_varint(clientModulus.length),
        clientModulus,

        append_scalar(0x04, expiry),

        Buffer.from([0x05]),
        write_varint(2),
        Buffer.from([0x41]),
        write_varint(1),
        append_scalar(9, nestedValue)
    ];

    return Buffer.concat(parts);
};

function finalize_uic(payload, privateKeyPem, keyDescriptor = 1) {
    if (!Buffer.isBuffer(payload) || payload.length === 0) {
        return null;
    };

    const privateKey = crypto.createPrivateKey(privateKeyPem);
    const modulusBits = privateKey.asymmetricKeyDetails?.modulusLength;

    if (modulusBits !== undefined && modulusBits !== 2048) {
        return null;
    };

    const modulusLength = 256;

    if (payload.length + 23 > modulusLength) {
        return null;
    };

    if (!Number.isInteger(keyDescriptor) || keyDescriptor < 0 || keyDescriptor > 0xFFFFFFFF) {
        return null;
    };

    const bbCount = modulusLength - payload.length - 23;

    const digest = crypto
        .createHash('sha1')
        .update(payload)
        .digest();

    const block = Buffer.concat([
        Buffer.from([0x4B]),
        Buffer.alloc(bbCount, 0xBB),
        Buffer.from([0xBA]),
        payload,
        digest,
        Buffer.from([0xBC])
    ]);

    if (block.length !== modulusLength) {
        return null;
    };

    const signature = crypto.privateEncrypt({
        key: privateKey,
        padding: crypto.constants.RSA_NO_PADDING
    }, block);

    if (signature.length !== modulusLength) {
        return null;
    };

    const descriptor = Buffer.alloc(4);
    descriptor.writeUInt32BE(keyDescriptor, 0);

    return Buffer.concat([descriptor, signature]);
};

function generate_uic(username, clientModulus, privateKeyPem, expiry = 0x0BBBD6F1, nestedValue = 0x0BD99AF1, keyDescriptor = 1) {
    const payload = build_uic_payload(
        username,
        clientModulus,
        expiry,
        nestedValue
    )

    return finalize_uic(
        payload,
        privateKeyPem,
        keyDescriptor
    );
};

function crc32(data) {
    if (!Buffer.isBuffer(data)) {
        return null;
    };
    
    return (~skycrypto.calculate_crc32(data, 0xFFFFFFFF)) >>> 0;
};

function build_aes_packet(aes_key, body) {
    try {
        if (!Buffer.isBuffer(aes_key) || aes_key.length !== 32) {
            return null;
        };

        if (!Buffer.isBuffer(body) || body.length === 0) {
            return null;
        };

        const iv = Buffer.alloc(16, 0);
        iv.writeUInt32BE(0x00000001, 0);
        iv.writeUInt32BE(0x00000001, 4);
        iv.writeUInt32BE(0xFFFFFFFF, 8);
        iv.writeUInt32BE(0xFFFF0000, 12);

        const encrypted_body = skycrypto.aes_ctr(
            aes_key,
            Buffer.from(body),
            iv
        );

        if (!Buffer.isBuffer(encrypted_body) || encrypted_body.length !== body.length) {
            return null;
        };

        const payload_len = encrypted_body.length + 2;
        if (payload_len > 0xFFFF) {
            return null;
        };

        const crc_low = crc32(encrypted_body) & 0xFFFF;
        const packet = Buffer.alloc(5 + payload_len);

        packet[0] = 0x17;
        packet[1] = 0x03;
        packet[2] = 0x01;
        packet.writeUInt16BE(payload_len, 3);
        encrypted_body.copy(packet, 5);
        packet.writeUInt16LE(crc_low, 5 + encrypted_body.length);

        return packet;
    } catch (error) {
        const time = functions.getTime();
        logger.error(`${time} [supernode] failed to build AES packet: ${error.message}`);
        return null;
    };
};

function build_auth_answer(answerCode, seq, aes_key, uic = null) {
    const has_uic = Buffer.isBuffer(uic);

    const out = Buffer.alloc(32 + (has_uic ? uic.length : 0));
    let n = 0;

    out[n++] = 0x41;
    out[n++] = has_uic ? 0x03 : 0x02;

    out[n++] = 0x00;
    out[n++] = 0x0A;
    n += varint.skype_write_varint(out, answerCode, n);

    out[n++] = 0x00;
    out[n++] = 0x02;
    out[n++] = seq;

    if (has_uic) {
        out[n++] = 0x04;
        out[n++] = 0x24;
        
        n += varint.skype_write_varint(out, uic.length, n);
        
        uic.copy(out, n);
        n += uic.length;
    };

    return build_aes_packet(aes_key, out.subarray(0, n));
};

function build_account_email(requestId, aes_key, email = '') {
    if (!Number.isInteger(requestId) || requestId <= 0 || typeof email !== 'string' || email.includes('\0')) {
        return null;
    };

    const header = Buffer.concat([
        Buffer.from([0x41, 0x02]),
        append_scalar(0x01, common.LOGIN_OK),
        append_scalar(0x02, requestId)
    ]);

    const email_field = Buffer.concat([
        Buffer.from([0x41, 0x01, 0x03, 0x20]),
        Buffer.from(email, 'utf8'),
        Buffer.from([0x00])
    ]);

    return build_aes_packet(
        aes_key,
        Buffer.concat([header, email_field])
    );
};

function build_contact_list_index(has_contacts, requestId, aes_key) {
    if (typeof has_contacts !== 'boolean' || !Number.isInteger(requestId) || requestId <= 0 || requestId > 0xFFFFFFFF) {
        return null;
    };

    const head = Buffer.alloc(16);
    let n = 0;

    head[n++] = 0x41;
    head[n++] = 0x02;

    head[n++] = 0x00;
    head[n++] = 0x01;
    n += varint.skype_write_varint(head, common.CONTACT_LIST_INDX_RES, n);

    head[n++] = 0x00;
    head[n++] = 0x02;
    n += varint.skype_write_varint(head, requestId, n);

    const body = has_contacts
        ? Buffer.from([
            0x41, 0x01,
            0x05, 0x38,
            0x41, 0x01,
            0x00, 0x07, 0x01
        ])
        : Buffer.from([0x41, 0x00]);

    const contact_list_index = Buffer.concat([
        head.subarray(0, n),
        body
    ]);

    return build_aes_packet(aes_key, contact_list_index);
};

function build_contact_list_index(has_contacts, requestId, aes_key) {
    if (typeof has_contacts !== 'boolean' || !Number.isInteger(requestId) || requestId <= 0 || requestId > 0xFFFFFFFF) {
        return null;
    };

    const head = Buffer.alloc(16);
    let n = 0;

    head[n++] = 0x41;
    head[n++] = 0x02;

    head[n++] = 0x00;
    head[n++] = 0x01;
    n += varint.skype_write_varint(head, common.CONTACT_LIST_INDX_RES, n);

    head[n++] = 0x00;
    head[n++] = 0x02;
    n += varint.skype_write_varint(head, requestId, n);

    const body = has_contacts
        ? Buffer.from([
            0x41, 0x01,
            0x05, 0x38,
            0x41, 0x01,
            0x00, 0x07, 0x01
        ])
        : Buffer.from([0x41, 0x00]);

    const contact_list_index = Buffer.concat([
        head.subarray(0, n),
        body
    ]);

    return build_aes_packet(aes_key, contact_list_index);
};

function build_contact_list(requestId, aes_key, contacts) {
    try {
        if (!Number.isInteger(requestId) || requestId <= 0 || requestId > 0xFFFFFFFF || !Array.isArray(contacts) || contacts.length > 1024) {
            return null;
        };

        const head = Buffer.alloc(16);
        let n = 0;

        head[n++] = 0x41;
        head[n++] = 0x02;

        head[n++] = 0x00;
        head[n++] = 0x01;
        n += varint.skype_write_varint(head, common.CONTACT_LIST_RES, n);

        head[n++] = 0x00;
        head[n++] = 0x02;
        n += varint.skype_write_varint(head, requestId, n);

        const entries = [];

        for (const row of contacts) {
            if (typeof row.contact !== 'string' || !/^[A-Za-z0-9_.-]{1,128}$/.test(row.contact)) {
                return null;
            };

            const contact_data = Buffer.concat([
                Buffer.from([
                    0x41, 0x02,
                    0x01, 0x01
                ]),

                Buffer.alloc(8),
                Buffer.from([0x03, 0x02]),
                Buffer.from(row.contact, 'utf8'),
                Buffer.from([0x00])
            ]);

            entries.push(
                Buffer.concat([
                    Buffer.from([0x05, 0x39]),
                    contact_data
                ])
            );
        };

        const count_buffer = Buffer.alloc(5);
        const count_length = varint.skype_write_varint(
            count_buffer,
            entries.length,
            0
        );

        const body = Buffer.concat([
            Buffer.from([0x41]),
            count_buffer.subarray(0, count_length),
            ...entries
        ]);

        return build_aes_packet(
            aes_key,
            Buffer.concat([
                head.subarray(0, n),
                body
            ])
        );
    } catch (error) {
        logger.error(`[builder] failed to build contact list: ${error.message}`);
        return null;
    };
};

function build_profile_body(profile = {}, username = '') {
    try {
        if (!profile || typeof profile !== 'object' || Array.isArray(profile)) {
            return null;
        };

        const raw_fullName = profile.fullName ?? profile.full_name ?? username;
        if (raw_fullName === undefined || raw_fullName === null) {
            return null;
        };

        const fullName = String(raw_fullName);
        if (fullName.length === 0) {
            return null;
        };

        const fullName_bytes = Buffer.from(fullName, 'utf8');
        if (fullName_bytes.length > 512 || fullName_bytes.includes(0)) {
            return null;
        };

        const fields = [];

        const append_string_field = (field_id, raw_value, max_length = 4096) => {
            if (raw_value === undefined || raw_value === null) {
                return true;
            };

            let value = raw_value;

            if (Array.isArray(value)) {
                if (value.some(item => item !== undefined && item !== null && typeof item !== 'string')) {
                    logger.warn(`[builder] skipping invalid profile string field 0x${field_id.toString(16)}`);
                    return true;
                };

                value = value
                    .filter(item => item !== undefined && item !== null && item.length > 0)
                    .join(' ');
            } else if (typeof value !== 'string') {
                logger.warn(`[builder] skipping invalid profile string field 0x${field_id.toString(16)}`);
                return true;
            };

            if (value.length === 0) {
                return true;
            };

            const value_bytes = Buffer.from(value, 'utf8');
            const field_id_bytes = write_varint(field_id);

            if (
                value_bytes.length > max_length ||
                value_bytes.includes(0) ||
                !field_id_bytes
            ) {
                logger.warn(`[builder] skipping invalid profile string field 0x${field_id.toString(16)}`);
                return true;
            };

            fields.push(Buffer.concat([
                Buffer.from([0x03]),
                field_id_bytes,
                value_bytes,
                Buffer.from([0x00])
            ]));

            return true;
        };

        const append_number_field = (field_id, value) => {
            const field_id_bytes = write_varint(field_id);
            const value_bytes = write_varint(value);

            if (!field_id_bytes || !value_bytes) {
                return false;
            };

            fields.push(Buffer.concat([
                Buffer.from([0x00]),
                field_id_bytes,
                value_bytes
            ]));

            return true;
        };

        const normalize_birthday = (raw_value) => {
            if (raw_value === undefined || raw_value === null || raw_value === '') {
                return null;
            };

            let year;
            let month;
            let day;

            if (raw_value instanceof Date) {
                if (Number.isNaN(raw_value.getTime())) {
                    return false;
                };

                year = raw_value.getFullYear();
                month = raw_value.getMonth() + 1;
                day = raw_value.getDate();
            } else if (typeof raw_value === 'number' && Number.isInteger(raw_value)) {
                if (raw_value === 0) {
                    return null;
                };

                const value = String(raw_value);
                if (!/^\d{8}$/.test(value)) {
                    return false;
                };

                year = Number(value.slice(0, 4));
                month = Number(value.slice(4, 6));
                day = Number(value.slice(6, 8));
            } else if (typeof raw_value === 'string') {
                const value = raw_value.trim();

                if (value === '0' || value === '00000000' || value === '0000-00-00') {
                    return null;
                };

                let match = value.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T].*)?$/);
                if (!match && /^\d{8}$/.test(value)) {
                    match = [value, value.slice(0, 4), value.slice(4, 6), value.slice(6, 8)];
                };

                if (!match) {
                    return false;
                };

                year = Number(match[1]);
                month = Number(match[2]);
                day = Number(match[3]);
            } else {
                return false;
            };

            if (year < 1 || year > 9999 || month < 1 || month > 12 || day < 1) {
                return false;
            };

            const leap_year = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
            const days_in_month = [
                31,
                leap_year ? 29 : 28,
                31,
                30,
                31,
                30,
                31,
                31,
                30,
                31,
                30,
                31
            ];

            if (day > days_in_month[month - 1]) {
                return false;
            };

            return (year * 10000) + (month * 100) + day;
        };

        const normalize_sex = (raw_value) => {
            if (raw_value === undefined || raw_value === null || raw_value === '') {
                return null;
            };

            if (typeof raw_value === 'number' && Number.isInteger(raw_value)) {
                return raw_value >= 0 && raw_value <= 2 ? raw_value : false;
            };

            if (typeof raw_value !== 'string') {
                return false;
            };

            const normalized = raw_value.trim().toUpperCase();

            if (/^[0-2]$/.test(normalized)) {
                return Number(normalized);
            };

            switch (normalized) {
                case 'UNKNOWN':
                    return 0;
                case 'MALE':
                    return 1;
                case 'FEMALE':
                    return 2;
                default:
                    return false;
            };
        };

        fields.push(Buffer.concat([
            Buffer.from([0x03]),
            write_varint(0x14),
            fullName_bytes,
            Buffer.from([0x00])
        ]));
        
        const birthday = normalize_birthday(profile.birthday);
        if (birthday === false) {
            logger.warn('[builder] skipping invalid profile birthday');
        } else if (birthday !== null && !append_number_field(0x1D, birthday)) {
            return null;
        };

        const sex = normalize_sex(profile.sex ?? profile.gender);
        if (sex === false) {
            logger.warn('[builder] skipping invalid profile sex');
        } else if (sex !== null && !append_number_field(0x21, sex)) {
            return null;
        };

        if (!append_string_field(0x2C, profile.province, 512)) {
            return null;
        };

        if (!append_string_field(0x30, profile.city, 512)) {
            return null;
        };

        if (!append_string_field(0x44, profile.homepage, 2048)) {
            return null;
        };

        if (!append_string_field(0x48, profile.about, 4096)) {
            return null;
        };

        fields.push(Buffer.concat([
            Buffer.from([0x00]),
            write_varint(0x4D),
            write_varint(1)
        ]));

        return Buffer.concat([
            Buffer.from([0x41]),
            write_varint(fields.length),
            ...fields
        ]);
    } catch (error) {
        logger.error(`[builder] failed to build profile body: ${error.message}`);
        return null;
    };
};

function build_native_documents(contacts, profile = {}, username = '') {
    try {
        if (!Array.isArray(contacts) || contacts.length > 1023) {
            return null;
        };

        const documents = new Map();
        const profile_body = build_profile_body(profile, username || profile.username || '');

        if (!profile_body) {
            return null;
        };

        const profile_checksum = skycrypto.calculate_crc32(
            profile_body,
            0xFFFFFFFF
        ) >>> 0;

        documents.set(profile_checksum, {
            name: 'p/profile',
            body: profile_body,
            checksum: profile_checksum
        });

        for (const contact of contacts) {
            if (typeof contact.contact !== 'string' || contact.contact.length === 0) {
                return null;
            };

            const login = Buffer.from(contact.contact, 'utf8');
            const fullName = Buffer.from(
                contact.fullName || contact.contact,
                'utf8'
            );

            if (login.includes(0) || fullName.includes(0) || login.length > 128 || fullName.length > 512) {
                return null;
            };

            const body = Buffer.concat([
                Buffer.from([0x41, 0x03]),

                Buffer.from([0x03]),
                write_varint(0x10),
                login,
                Buffer.from([0x00]),

                Buffer.from([0x03]),
                write_varint(0x14),
                fullName,
                Buffer.from([0x00]),

                append_scalar(0x79, 2)
            ]);

            const checksum = skycrypto.calculate_crc32(
                body,
                0xFFFFFFFF
            ) >>> 0;

            if (documents.has(checksum)) {
                return null;
            };

            documents.set(checksum, {
                name: `u/${contact.contact}`,
                body,
                checksum
            });
        };

        return documents;
    } catch (error) {
        logger.error(`[builder] failed to build native documents: ${error.message}`);
        return null;
    };
};

function build_doc_manifest(requestId, aes_key, documents, revision = 0) {
    try {
        if (!Number.isInteger(requestId) || requestId <= 0 || requestId > 0xFFFFFFFF || !(documents instanceof Map) || documents.size > 1024 || !Number.isInteger(revision) || revision <= 0 || revision > 0xFFFFFFFF) {
            return null;
        };

        const checksums = [];

        for (const [checksum, document] of documents) {
            if (!Number.isInteger(checksum) || checksum < 0 || checksum > 0xFFFFFFFF || !document || !Buffer.isBuffer(document.body) || typeof document.name !== 'string' || (document.checksum >>> 0) !== (checksum >>> 0)) {
                return null;
            };

            checksums.push(checksum >>> 0);
        };

        const checksum_buffer = Buffer.alloc(checksums.length * 4);

        checksums.forEach((checksum, index) => {
            checksum_buffer.writeUInt32BE(
                checksum,
                index * 4
            );
        });

        const header = Buffer.concat([
            Buffer.from([0x41, 0x02]),
            append_scalar(0x01, 0x1450),
            append_scalar(0x02, requestId)
        ]);

        const manifest = Buffer.concat([
            Buffer.from([0x41, 0x02]),
            append_scalar(0x36, revision),

            Buffer.from([0x04]),
            write_varint(0x35),
            write_varint(checksum_buffer.length),
            checksum_buffer
        ]);

        const packet = build_aes_packet(
            aes_key,
            Buffer.concat([header, manifest])
        );

        if (!packet) {
            return null;
        };

        return {
            packet,
            revision,
            documents
        };
    } catch (error) {
        logger.error(`[builder] failed to build document manifest: ${error.message}`);
        return null;
    };
};

function build_native_document(requestId, aes_key, revision, document_name, document_body) {
    try {
        if (!Number.isInteger(requestId) || requestId <= 0 || !Number.isInteger(revision) || revision <= 0 || !Buffer.isBuffer(document_body) || typeof document_name !== 'string') {
            return null;
        };

        const name = Buffer.from(document_name, 'utf8');

        if (name.length === 0 || name.includes(0)) {
            return null;
        };

        const header = Buffer.concat([
            Buffer.from([0x41, 0x02]),
            append_scalar(0x01, 0x1450),
            append_scalar(0x02, requestId)
        ]);

        const document = Buffer.concat([
            Buffer.from([0x41, 0x02]),
            append_scalar(0x36, revision),

            Buffer.from([0x05]),
            write_varint(0x37),

            Buffer.from([0x41, 0x02]),
            Buffer.from([0x03]),
            write_varint(0x34),
            name,
            Buffer.from([0x00]),
            Buffer.from([0x04]),
            write_varint(0x33),
            write_varint(document_body.length),
            document_body
        ]);

        return build_aes_packet(
            aes_key,
            Buffer.concat([header, document])
        );
    } catch (error) {
        logger.error(`[builder] failed to build native document response: ${error.message}`);
        return null;
    };
};

function build_native_document_ack(requestId, aes_key, revision) {
    try {
        if (!Number.isInteger(requestId) || requestId <= 0 || !Number.isInteger(revision) || revision <= 0 || revision > 0xFFFFFFFF) {
            return null;
        };

        const header = Buffer.concat([
            Buffer.from([0x41, 0x02]),
            append_scalar(0x01, 0x1450),
            append_scalar(0x02, requestId)
        ]);

        const acknowledgement = Buffer.concat([
            Buffer.from([0x41, 0x01]),
            append_scalar(0x36, revision)
        ]);

        return build_aes_packet(
            aes_key,
            Buffer.concat([header, acknowledgement])
        );
    } catch (error) {
        logger.error(`[builder] failed to build native document ACK: ${error.message}`);
        return null;
    };
};

module.exports = {
    build_nack_packet,
    build_probe_ok,
    build_tcp_handshake,
    build_new_tcp_handshake,
    build_tcp_accept,
    build_tcp_netstats,
    build_tcp_ack,
    generate_uic,
    build_auth_answer,
    build_account_email,
    build_contact_list_index,
    build_contact_list,
    build_doc_manifest,
    build_native_documents,
    build_native_document,
    build_native_document_ack
};