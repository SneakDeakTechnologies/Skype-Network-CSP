'use strict';

const functions = require('../../functions/functions.js');
const logger = require('../../logger/logger.js');
const path = require('node:path');
const koffi = require('koffi');

const DLL_NAME = 'ext42_x86.dll';
const MAX_INPUT_BYTES = 64 * 1024;
const MAX_BINARY_BYTES = 4 * 1024 * 1024;
const MAX_OBJECTS = 4096;
const MAX_NESTING_DEPTH = 8;
const NATIVE_PACK_CAPACITY = 0x50000;
const UINT32_MAX = 0xffffffff;

if (process.platform !== 'win32' || process.arch !== 'ia32') {
    const time = functions.getTime();
    logger.error(`${time} [supernode] ${DLL_NAME} requires 32-bit Windows Node.js; current runtime is ${process.platform}/${process.arch}`);
    throw new Error(`${DLL_NAME} requires 32-bit Windows Node.js`);
};

const dll_path = path.resolve('crypto', 'libs', DLL_NAME);
let native;

try {
    native = koffi.load(dll_path);
} catch (error) {
    const time = functions.getTime();
    logger.error(`${time} [supernode] failed to load ${dll_path}: ${error.message}`);
    throw error;
};

const main_unpack = native.func('char * __cdecl main_unpack(uint8_t *indata, uint32_t inlen)');
const main_pack = native.func('int __cdecl main_pack(uint8_t *mythings, int mythings_len, uint8_t *outdata)');
const main_unpack_test = native.func('int __cdecl main_unpack_test(uint8_t *indata, uint32_t inlen, uint32_t test_type, uint32_t test_id)');
const main_unpack_get_binary = native.func('int __cdecl main_unpack_get_binary(uint8_t *indata, uint32_t inlen, uint32_t wanted_type, uint32_t wanted_id, uint8_t *outdata, uint32_t out_capacity, _Out_ uint32_t *out_size)');

function log_error(message) {
    const time = functions.getTime();
    logger.error(`${time} [supernode] ${message}`);
};

function is_uint32(value) {
    return Number.isInteger(value) && value >= 0 && value <= UINT32_MAX;
};

function validate_input_buffer(data, label = 'EXT input') {
    if (!Buffer.isBuffer(data)) {
        log_error(`${label} must be a Buffer`);
        return false;
    };

    if (data.length === 0) {
        log_error(`${label} is empty`);
        return false;
    };

    if (data.length > MAX_INPUT_BYTES) {
        log_error(`${label} is too large (${data.length} bytes; limit ${MAX_INPUT_BYTES})`);
        return false;
    };

    if (data.indexOf(0x42) === -1) {
        log_error(`${label} does not contain marker 0x42`);
        return false;
    };

    return true;
};

function unpack_ext_objects(ext_params, options = {}) {
    if (!validate_input_buffer(ext_params)) {
        return null;
    };

    let json_text;

    try {
        json_text = main_unpack(ext_params, ext_params.length);
    } catch (error) {
        log_error(`main_unpack call failed: ${error.message}`);
        return null;
    };

    if (typeof json_text !== 'string' || json_text.length === 0) {
        log_error('main_unpack returned an empty or invalid JSON string');
        return null;
    };

    let decoded;
    try {
        decoded = JSON.parse(json_text);
    } catch (error) {
        log_error(`main_unpack returned invalid JSON: ${error.message}`);
        return null;
    };

    if (!decoded || !Array.isArray(decoded.objects)) {
        log_error('main_unpack JSON has no objects array');
        return null;
    };

    if (decoded.ok !== true) {
        log_error(`4142 decoder failed: ${decoded.error || 'unknown error'}; partial objects=${decoded.objects.length}`);

        if (options && options.allow_partial === true) {
            return decoded;
        };

        return null;
    };

    return decoded;
};

function get_native_buffer_address(buffer) {
    if (typeof koffi.address !== 'function') {
        throw new Error('This Koffi version does not expose koffi.address(Buffer); update Koffi to pack pointer-backed EXT42 objects');
    };

    const address = koffi.address(buffer);
    const value = typeof address === 'bigint' ? address : BigInt(address);

    if (value <= 0n || value > 0xffffffffn) {
        throw new RangeError('Buffer address does not fit the 32-bit skype_thing.m field');
    };

    return Number(value);
};

function build_native_objects(objects, retained_buffers, state, label = 'objects', depth = 0) {
    if (!Array.isArray(objects)) {
        throw new TypeError(`${label} must be an array`);
    };

    if (depth > MAX_NESTING_DEPTH) {
        throw new RangeError(`${label} exceeds the maximum nesting depth (${MAX_NESTING_DEPTH})`);
    };

    if (objects.length > MAX_OBJECTS) {
        throw new RangeError(`${label} may contain at most ${MAX_OBJECTS} items`);
    };

    state.total_objects += objects.length;
    if (state.total_objects > MAX_OBJECTS) {
        throw new RangeError(`the complete object tree may contain at most ${MAX_OBJECTS} items`);
    };

    const input = Buffer.alloc(objects.length * 16);
    retained_buffers.push(input);

    objects.forEach((object, index) => {
        const object_label = `${label}[${index}]`;

        if (!object || typeof object !== 'object' || Array.isArray(object)) {
            throw new TypeError(`${object_label} must be an object`);
        };

        const type = object.type;
        const id = object.id;
        let m = object.m ?? 0;
        let n = object.n ?? 0;

        if (!is_uint32(type)) {
            throw new RangeError(`${object_label}.type must be a uint32`);
        };
        if (!is_uint32(id)) {
            throw new RangeError(`${object_label}.id must be a uint32`);
        };
        if (![0, 1, 2, 5, 6].includes(type)) {
            throw new RangeError(`${object_label}.type=${type} is not supported by this main_pack bridge (supported: 0, 1, 2, 5, 6)`);
        };

        if (type === 5) {
            if (!Array.isArray(object.children)) {
                throw new TypeError(`${object_label}.children must be an array for type 5`);
            };
            
            const child_objects = build_native_objects(
                object.children,
                retained_buffers,
                state,
                `${object_label}.children`,
                depth + 1
            );
            const child_list = Buffer.alloc(16);

            child_list.writeUInt32LE(0xFFFFFFFF, 0);
            child_list.writeUInt32LE(
                object.children.length === 0 ? 0 : get_native_buffer_address(child_objects),
                4
            );
            child_list.writeUInt32LE(object.children.length, 8);
            child_list.writeUInt32LE(object.children.length, 12);

            retained_buffers.push(child_list);
            m = get_native_buffer_address(child_list);
            n = 0;
        } else if (type === 6) {
            if (!Buffer.isBuffer(object.data)) {
                throw new TypeError(`${object_label}.data must be a Buffer for type 6`);
            };
            if ((object.data.length & 3) !== 0) {
                throw new RangeError(`${object_label}.data length must be a multiple of 4 for type 6`);
            };
            if (object.data.length > MAX_BINARY_BYTES) {
                throw new RangeError(`${object_label}.data exceeds ${MAX_BINARY_BYTES} bytes`);
            };
            if (object.n !== undefined && object.n !== object.data.length) {
                throw new RangeError(`${object_label}.n must match ${object_label}.data.length for type 6`);
            };

            retained_buffers.push(object.data);
            m = get_native_buffer_address(object.data);
            n = object.data.length;
        } else {
            if (!is_uint32(m)) {
                throw new RangeError(`${object_label}.m must be a uint32`);
            };
            if (!is_uint32(n)) {
                throw new RangeError(`${object_label}.n must be a uint32`);
            };
            if (type === 2 && n > 65535) {
                throw new RangeError(`${object_label}.n for type 2 is a port and must be 0..65535`);
            };
        };

        const offset = index * 16;
        input.writeUInt32LE(type, offset);
        input.writeUInt32LE(id, offset + 4);
        input.writeUInt32LE(m, offset + 8);
        input.writeUInt32LE(n, offset + 12);
    });

    return input;
};

function pack_ext_objects(objects) {
    if (!Array.isArray(objects) || objects.length === 0) {
        log_error('objects must be a non-empty array');
        return null;
    };

    if (objects.length > MAX_OBJECTS) {
        log_error(`objects may contain at most ${MAX_OBJECTS} items`);
        return null;
    };

    const retained_buffers = [];
    const state = { total_objects: 0 };
    let input;

    try {
        input = build_native_objects(objects, retained_buffers, state);
    } catch (error) {
        log_error(error.message);
        return null;
    };

    const output = Buffer.alloc(NATIVE_PACK_CAPACITY);
    let result_length;

    try {
        result_length = main_pack(input, objects.length, output);
    } catch (error) {
        log_error(`main_pack call failed: ${error.message}`);
        return null;
    };

    if (!Number.isInteger(result_length) || result_length <= 0 || result_length > output.length) {
        log_error(`main_pack returned invalid length: ${result_length}`);
        return null;
    };

    if (output[0] !== 0x42) {
        log_error('main_pack result does not begin with marker 0x42');
        return null;
    };

    void retained_buffers;
    return Buffer.from(output.subarray(0, result_length));
};

function unpack_ext_binary(ext_params, wanted_type = 4, wanted_id, options = {}) {
    if (!validate_input_buffer(ext_params, 'EXT binary input')) {
        return null;
    };

    if (!is_uint32(wanted_type) || !is_uint32(wanted_id)) {
        log_error('wanted_type and wanted_id must be uint32 values');
        return null;
    };

    const output_capacity = options.output_capacity ?? 1024 * 1024;
    if (!Number.isInteger(output_capacity) || output_capacity < 1 || output_capacity > MAX_BINARY_BYTES) {
        log_error(`output_capacity must be an integer between 1 and ${MAX_BINARY_BYTES}`);
        return null;
    };

    const output = Buffer.alloc(output_capacity);
    const output_size = [0];
    let result;

    try {
        result = main_unpack_get_binary(
            ext_params,
            ext_params.length,
            wanted_type,
            wanted_id,
            output,
            output.length,
            output_size
        );
    } catch (error) {
        log_error(`main_unpack_get_binary call failed: ${error.message}`);
        return null;
    };

    if (result !== 1) {
        return null;
    };

    const length = output_size[0];
    if (!Number.isInteger(length) || length < 0 || length > output.length) {
        log_error(`main_unpack_get_binary returned invalid data length: ${length}`);
        return null;
    };

    return Buffer.from(output.subarray(0, length));
};

function has_ext_object(ext_params, wanted_type, wanted_id) {
    if (!validate_input_buffer(ext_params, 'EXT test input')) {
        return false;
    };

    if (!is_uint32(wanted_type) || !is_uint32(wanted_id)) {
        log_error('wanted_type and wanted_id must be uint32 values');
        return false;
    };

    try {
        return main_unpack_test(ext_params, ext_params.length, wanted_type, wanted_id) === 1;
    } catch (error) {
        log_error(`main_unpack_test call failed: ${error.message}`);
        return false;
    };
};

function parse_ext_objects(decoded) {
    if (!decoded || !Array.isArray(decoded.objects)) {
        log_error('decoded result has no objects array');
        return null;
    };

    const format_value = (value) => {
        if (typeof value !== 'number') return String(value);
        return '0x' + (value >>> 0).toString(16).toUpperCase().padStart(8, '0');
    };

    for (const obj of decoded.objects) {
        const time = functions.getTime();
        logger.info(
            `${time} [supernode] type=${obj.type} id=${obj.id} ` +
            `m=${format_value(obj.m)} n=${format_value(obj.n)}`
        );
    };

    return decoded.objects;
};

module.exports = {
    unpack_ext_objects,
    pack_ext_objects,
    unpack_ext_binary,
    has_ext_object,
    parse_ext_objects
};