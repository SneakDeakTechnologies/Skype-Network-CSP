'use strict';

function read_7bit_uint(buffer, offset = 0) {
    if (!Buffer.isBuffer(buffer)) {
        throw new TypeError('buffer must be a Buffer');
    };

    if (!Number.isInteger(offset) ||offset < 0 ||offset > buffer.length) {
        throw new RangeError('Invalid offset');
    };

    let value = 0;

    for (let i = 0; i < 5; i++) {
        if (offset >= buffer.length) {
            throw new RangeError('Incomplete 7-bit uint');
        };

        const byte = buffer[offset++];
        const part = byte & 0x7F;

        if (i === 4 && part > 0x0F) {
            throw new RangeError('7-bit uint exceeds uint32');
        };

        value += part * (2 ** (i * 7));

        if ((byte & 0x80) === 0) {
            return {
                value,
                offset,
                bytes_read: i + 1
            };
        };
    };

    throw new RangeError('7-bit uint is too long');
};

function read_7bit_uint_array(buffer, offset, count) {
    if (!Number.isInteger(count) || count < 0) {
        throw new RangeError('Invalid uint array count');
    };

    const values = [];

    for (let i = 0; i < count; i++) {
        const decoded = read_7bit_uint(buffer, offset);

        values.push(decoded.value);
        offset = decoded.offset;
    };

    return {
        values,
        offset
    };
};

function read_7bit_bytes(buffer, offset = 0) {
    const decoded_length = read_7bit_uint(buffer, offset);
    const length = decoded_length.value;

    const start = decoded_length.offset;
    const end = start + length;

    if (end > buffer.length) {
        throw new RangeError('Incomplete length-prefixed data');
    };

    return {
        value: buffer.subarray(start, end),
        length,
        offset: end
    };
};

function skype_write_varint(buffer, value, offset = 0) {
    if (!Buffer.isBuffer(buffer)) {
        return null;
    };

    if (!Number.isInteger(value) || value < 0 || value > 0xFFFFFFFF) {
        return null;
    };

    if (!Number.isInteger(offset) || offset < 0 || offset > buffer.length) {
        return null;
    };

    const encoded = [];
    let remaining = value;

    while (remaining > 0x7F) {
        encoded.push((remaining & 0x7F) | 0x80);
        remaining = Math.floor(remaining / 0x80);
    };

    encoded.push(remaining & 0x7F);

    if (offset + encoded.length > buffer.length) {
        return null;
    };

    for (let i = 0; i < encoded.length; i++) {
        buffer[offset + i] = encoded[i];
    };

    return encoded.length;
};

module.exports = {
    read_7bit_uint,
    read_7bit_uint_array,
    read_7bit_bytes,
    skype_write_varint
};