const skycrypto = require('../../crypto/skycrypto.js');

const max_document_size = 48 * 1024;

function validate_document(name, body, checksum) {
    if (typeof name !== 'string' || name.length === 0 || name.includes('\0') || Buffer.byteLength(name, 'utf8') > 255) {
        return false;
    };

    if (!Buffer.isBuffer(body) || body.length === 0 || body.length > max_document_size) {
        return false;
    };

    if (!Number.isInteger(checksum) || checksum < 0 || checksum > 0xFFFFFFFF) {
        return false;
    };

    return (skycrypto.calculate_crc32(body, 0xFFFFFFFF) >>> 0) === (checksum >>> 0);
};

async function seed_and_read(mysql, owner, generated_documents) {
    const [rows] = await mysql.promise().query(
        `SELECT document_name, checksum, body, document_source, revision
        FROM skype_native_documents
        WHERE owner = ?
        ORDER BY document_name`,
        [owner]
    );

    const stored_by_name = new Map();
    const documents = new Map();
    let revision = 0;

    for (const row of rows) {
        const name = Buffer.isBuffer(row.document_name)
            ? row.document_name.toString('utf8')
            : String(row.document_name);
        const checksum = Number(row.checksum) >>> 0;
        const document = {
            name,
            body: Buffer.from(row.body),
            checksum,
            document_source: Number(row.document_source) || 0
        };

        revision = Math.max(revision, Number(row.revision) || 0);
        stored_by_name.set(name, document);
        documents.set(checksum, document);
    };

    if (revision >= 0xFFFFFFFF && generated_documents.size > 0) {
        for (const generated of generated_documents.values()) {
            const stored = stored_by_name.get(generated.name);
            if (!stored || (stored.document_source !== 1 && (stored.checksum !== generated.checksum || !stored.body.equals(generated.body)))) {
                throw new Error('Central Storage revision limit reached');
            };
        };
    };

    const next_revision = revision + 1;
    const values = [];

    for (const [checksum, generated] of generated_documents) {
        const stored = stored_by_name.get(generated.name);

        if (stored && stored.document_source === 1) {
            continue;
        };

        if (stored && stored.checksum === checksum && stored.body.equals(generated.body)) {
            continue;
        };

        values.push([
            owner,
            Buffer.from(generated.name, 'utf8'),
            checksum,
            generated.body,
            0,
            next_revision
        ]);

        if (stored) {
            documents.delete(stored.checksum);
        };

        documents.set(checksum, generated);
    };

    if (values.length > 0) {
        await mysql.promise().query(
            `INSERT INTO skype_native_documents
                (owner, document_name, checksum, body, document_source, revision)
            VALUES ?
            ON DUPLICATE KEY UPDATE
                revision = IF(
                    document_source = 0 AND
                    (checksum <> VALUES(checksum) OR body <> VALUES(body)),
                    VALUES(revision), revision
                ),
                checksum = IF(document_source = 0, VALUES(checksum), checksum),
                body = IF(document_source = 0, VALUES(body), body)`,
            [values]
        );

        revision = next_revision;
    };

    return {
        revision: revision || 1,
        documents
    };
};

async function put_document(mysql, owner, name, body, checksum, document_source = 1) {
    if (!validate_document(name, body, checksum) || ![0, 1].includes(document_source)) {
        return null;
    };

    const [rows] = await mysql.promise().query(
        `SELECT
            COALESCE((
                SELECT MAX(revision)
                FROM skype_native_documents
                WHERE owner = ?
            ), 0) AS revision,
            doc.checksum,
            doc.body,
            doc.document_source
        FROM (SELECT 1) AS item
        LEFT JOIN skype_native_documents AS doc
            ON doc.owner = ? AND doc.document_name = ?
        LIMIT 1`,
        [owner, owner, Buffer.from(name, 'utf8')]
    );

    const row = rows[0] || {};
    const current_revision = Number(row.revision) || 0;
    const existing_body = Buffer.isBuffer(row.body) ? row.body : null;
    const existing_checksum = row.checksum === null || row.checksum === undefined
        ? null
        : Number(row.checksum) >>> 0;
    const same_body = existing_body && existing_checksum === (checksum >>> 0) && existing_body.equals(body);

    if (same_body) {
        if (Number(row.document_source) !== document_source) {
            await mysql.promise().query(
                `UPDATE skype_native_documents
                SET document_source = ?
                WHERE owner = ? AND document_name = ?`,
                [document_source, owner, Buffer.from(name, 'utf8')]
            );
        };

        return {
            revision: current_revision || 1,
            changed: false
        };
    };

    if (current_revision >= 0xFFFFFFFF) {
        return null;
    };

    const revision = current_revision + 1;

    await mysql.promise().query(
        `INSERT INTO skype_native_documents
            (owner, document_name, checksum, body, document_source, revision)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            checksum = VALUES(checksum),
            body = VALUES(body),
            document_source = VALUES(document_source),
            revision = VALUES(revision)`,
        [owner, Buffer.from(name, 'utf8'), checksum >>> 0, body, document_source, revision]
    );

    return {
        revision,
        changed: true
    };
};

module.exports = {
    seed_and_read,
    put_document,
    validate_document
};