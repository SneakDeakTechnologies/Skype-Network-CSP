/*
    * @file Skype UDP SuperNode
    * @author Nikita Konev nikitakonev892@gmail.com
    * @copyright SneakDeak Technologies 2026
*/
const functions = require('./functions/functions.js');
const builder = require('./proto/builder/builder.js');
const skycrypto = require('./crypto/skycrypto.js');
const common = require('./proto/common/common.js');
const UDPdgram = require('./sockets/UDPdgram.js');
const logger = require('./logger/logger.js');
const dgram = require('node:dgram');
const dotenv = require('dotenv');

dotenv.config({ 
    path: './config.env',
    quiet: true
});

const udp_config = {
    host: process.env.udp_host,
    port: process.env.udp_port
};

const supernode = dgram.createSocket("udp4");

supernode.on("message", async (msg, rinfo) => {

    const time = functions.getTime();
    const client = `${rinfo.address}:${rinfo.port}`;

    const hex = msg.toString('hex');
    logger.info(`${time} [supernode] received ${msg.length} bytes from ${client}: ${hex}`);

    if (msg.length < 3) {
        return;
    };

    try {
        const transId = msg.readUInt16BE(0);
        const packetType = msg[2];

        switch (packetType) {
            case common.PKT_TYPE_OBFSUK:
                const nack_packet = builder.build_nack_packet(transId, rinfo, client);
                UDPdgram.send(nack_packet, nack_packet.length, supernode, rinfo, client);
                return;
                /*const iv = msg.readUInt32BE(3);
                const seed = skycrypto.calculate_seed(transId, msg, iv, 0, packetType, udp_config.host);

                const header_crc = msg.readUInt32BE(7);
                logger.info(`${time} [supernode] probe header: transId=${transId.toString(16)} packetType=${packetType.toString(16)} iv=${iv.toString(16)} crc32=${header_crc.toString(16)}`);
                
                const body = msg.subarray(11);
                const rc4_key = skycrypto.create_rc4_context(seed);

                //logger.info(`${time} [supernode] rc4 key=${rc4_key.toString('hex')}`);

                skycrypto.rc4(body, rc4_key, false);
                logger.info(`${time} [supernode] decrypted body: ${body.toString('hex')}`);

                const calculated_crc = skycrypto.calculate_crc32(body, 0xFFFFFFFF) >>> 0;

                if (calculated_crc !== header_crc) {
                    logger.info(`${time} [supernode] crc mismatch: calculated=${calculated_crc.toString(16)} received=${header_crc.toString(16)}`);
                    break;
                };
                
                const cmd = body[1] >> 3;
                const requestId = body.readUInt16BE(3);
                const paramListType = body[5];

                logger.info(`${time} [supernode] cmd=${cmd.toString(16)} requestId=${requestId.toString(16)} paramtListType=${paramListType.toString(16)}`);

                switch (cmd) {
                    case common.CMD_PROBE:
                        const probeOk = await builder.build_probe_ok(transId, udp_config.host, "0.0.0.0", client, requestId);
                        UDPdgram.send(probeOk, probeOk.length, supernode, rinfo, client);
                    break;
                };*/
            break;

            case common.PKT_TYPE_RESEND:
                const seed = skycrypto.calculate_seed(transId, msg, null, rinfo, packetType, udp_config.host);
                const rc4_key = skycrypto.create_rc4_context(seed);

                const header_crc = msg.readUInt32BE(12);
                logger.info(`${time} [supernode] probe header: transId=${transId.toString(16)} packetType=${packetType.toString(16)} crc32=${header_crc.toString(16)}`);
                
                const body = Buffer.alloc(msg.length - 16);
                msg.copy(body, 0, 16, msg.length);
                
                skycrypto.rc4(body, rc4_key, false);
                logger.info(`${time} [supernode] decrypted body: ${body.toString('hex')}`);

                const calculated_crc = skycrypto.calculate_crc32(body, 0xFFFFFFFF) >>> 0;

                if (calculated_crc !== header_crc) {
                    logger.info(`${time} [supernode] crc mismatch: calculated=${calculated_crc.toString(16)} received=${header_crc.toString(16)}`);
                    break;
                };
                
                const cmd = body[1] >> 3;
                const requestId = body.readUInt16BE(3);
                const paramListType = body[5];
                const nbObj = body[6];

                logger.info(`${time} [supernode] cmd=$${cmd.toString(10)} requestId=${requestId.toString(16)} paramLisType=${paramListType.toString(16)} nbObj=${nbObj.toString(16)}`);

                switch (cmd) {
                    case common.CMD_PROBE:
                        const probeOk = await builder.build_probe_ok(transId, udp_config.host, rinfo.address, client, requestId);
                        UDPdgram.send(probeOk, probeOk.length, supernode, rinfo, client);
                    break;
                };
            break;

            default:
                const default_nack_packet = builder.build_nack_packet(transId, rinfo, client);
                UDPdgram.send(default_nack_packet, default_nack_packet.length, supernode, rinfo, client);
                return;
            break;
        };
    } catch (error) {
        const time = functions.getTime();
        logger.warn(`${time}} [supernode] invalid packet: ${error.message}`);
    };
});

supernode.on('error', (error) => {
    const time = functions.getTime();

    logger.error(`\n${time} [supernode] error: ${error.stack}`);
    supernode.close();
});

supernode.on('listening', () => {
    const address = supernode.address();
    process.title = 'Skype UDP SuperNode';

    logger.info(`Skype UDP SuperNode listening on ${address.address}:${address.port}`);
    logger.info(`Waiting for packets..\n`);
});

supernode.bind(udp_config.port, udp_config.host);