const functions = require('../functions/functions.js');
const common = require('../proto/common/common.js');
const logger = require("../logger/logger.js");
const crypto = require('crypto');
const koffi = require("koffi");
const path = require('path');
const fs = require('fs');

const skyrc4 = koffi.load('crypto/libs/skyrc4_x86.dll');
const avatar_exts = ['.png', '.jpg', '.jpeg', '.bmp'];
const avatar_dir = path.resolve('users/avatars');

const RC4_context = koffi.struct('RC4_context', {
    from_IP: 'uint32_t',
    to_IP: 'uint32_t',
    from_port: 'uint32_t',
    to_port: 'uint32_t',
    seq: 'uint32_t',

    i: 'uint8_t',
    j: 'uint8_t',
    s: koffi.array('uint8_t', 256),

    next: 'void *'
});

const Skype_RC4_Get_Expanded_Key = skyrc4.func(
    'void Skype_RC4_Get_Expanded_Key(uint32_t iv, void *iv2, void *output_key, uint32_t flags, uint32_t iv2_bytes)'
);

const Skype_RC4_Expand_IV = skyrc4.func(
    'void Skype_RC4_Expand_IV(' +
    'uint32_t iv, void *iv2, RC4_context *rc4_out, ' +
    'uint32_t flags, uint32_t iv2_bytes)'
);

const RC4_crypt = skyrc4.func(
    'void RC4_crypt(uint8_t *buffer, uint32_t bytes, RC4_context *rc4_ctx, uint32_t test)'
);

function calculate_seed(transId, msg, remote_iv, remote, packetType, supernode_host) {
    if (packetType === common.PKT_TYPE_OBFSUK) {
        const toCrc = Buffer.alloc(12);

        const ipBytes = (ip) => Buffer.from(ip.split('.').map(Number).reverse());
        toCrc.set(ipBytes(supernode_host), 4);
        toCrc.writeUInt16LE(transId, 8);

        const crc = calculate_crc32(toCrc, 0xFFFFFFFF);
        return (crc ^ remote_iv) >>> 0;
    };

    const transId_bytes = Buffer.alloc(2);
    let seed;

    msg.copy(transId_bytes, 0, 0, 2);
    const transId_uint = ((transId_bytes[0] << 8) | transId_bytes[1]) >>> 0;
    
    const seed_bytes = Buffer.alloc(4);
    msg.copy(seed_bytes, 0, 4, 8);
    const seed_uint = ((seed_bytes[0] << 24) | (seed_bytes[1] << 16) | (seed_bytes[2] << 8) | seed_bytes[3]) >>> 0;
    
    const supernode_host_bytes = supernode_host.split('.').map(Number);
    const supernode_ip_uint = ((supernode_host_bytes[0] << 24) | 
                               (supernode_host_bytes[1] << 16) | 
                               (supernode_host_bytes[2] << 8) | 
                               supernode_host_bytes[3]) >>> 0;
    
    const client_ip_bytes = remote.address.split('.').map(Number);
    const client_ip_uint = ((client_ip_bytes[0] << 24) | 
                            (client_ip_bytes[1] << 16) | 
                            (client_ip_bytes[2] << 8) | 
                            client_ip_bytes[3]) >>> 0;
    
    const to_crc = Buffer.alloc(12);
    
    to_crc.writeUInt32BE(supernode_ip_uint, 0);
    to_crc.writeUInt32BE(client_ip_uint, 4);
    
    to_crc[8] = transId_uint & 0xFF;
    to_crc[9] = (transId_uint >> 8) & 0xFF;
    to_crc[10] = 0;
    to_crc[11] = 0;
    
    const crc_to_crc = calculate_crc32(to_crc, 0xFFFFFFFF);
    seed = (transId_uint ^ seed_uint) >>> 0;
    
    return seed;
};

function create_crc32_table() {
    const table = new Array(256);
    const poly = 0xEDB88320;
    
    for (let i = 0; i < 256; i++) {
        let crc = i;

        for (let j = 0; j < 8; j++) {
            crc = (crc & 1) !== 0 ? (crc >>> 1) ^ poly : (crc >>> 1);
        };
        
        table[i] = crc >>> 0;
    };

    return table;
};

function calculate_crc32(buffer, salt) {
    const crc32_table = create_crc32_table();
    let crc = salt >>> 0;
    
    for (let i = 0; i < buffer.length; i++) {
        crc = crc32_table[(crc ^ buffer[i]) & 0xFF] ^ (crc >>> 8);
    };
    
    return crc >>> 0;
};

function get_rc4_key(seed) {
    try {
        const rc4_key = Buffer.alloc(88);
        Skype_RC4_Get_Expanded_Key(seed, 0, rc4_key, 1, 0);
        
        return rc4_key;
    } catch (error) {
        const time = functions.getTime();
        logger.error(`${time} [supernode] DLL error: ${error.message}`);
    };
};

function create_rc4_context(seed) {
    if (!Number.isInteger(seed) ||seed < 0 ||seed > 0xFFFFFFFF) {
        throw new RangeError('Invalid RC4 seed');
    };

    const ctx = koffi.alloc(RC4_context, 1);

    try {
        Skype_RC4_Expand_IV(seed >>> 0, null, ctx, 1, 0);
        return ctx;
    } catch (error) {
        koffi.free(ctx);
        throw error;
    };
};

function create_new_rc4_context(iv, iv2) {
    if (!Number.isInteger(iv) || iv < 0 || iv > 0xFFFFFFFF) {
        throw new RangeError('Invalid RC4 IV');
    };

    const ctx = koffi.alloc(RC4_context, 1);

    try {
        Skype_RC4_Expand_IV(iv >>> 0, iv2, ctx, 1, iv2.length);
        return ctx;
    } catch (error) {
        koffi.free(ctx);
        throw error;
    };
};

function rc4(data, ctx, test = false) {
    if (!Buffer.isBuffer(data)) {
        throw new TypeError('RC4 data must be a Buffer');
    };

    if (!ctx) {
        throw new TypeError('RC4 context is required');
    };

    RC4_crypt(
        data,
        data.length,
        ctx,
        test ? 1 : 0
    );

    return data;
};

function free_rc4_context(ctx) {
    if (ctx) {
        koffi.free(ctx);
    };
};

function compute_md5_hash(prefix, shared_secret) {
    if ((prefix !== 'O' && prefix !== 'I') || !Buffer.isBuffer(shared_secret) || shared_secret.length !== 48) {
        return null;
    };

    const hashed = crypto.createHash('md5').update(prefix, 'ascii').update(shared_secret).digest().subarray(0, 8);
    return hashed;
};

function encode_cmd(cmd, lowBits = 0x03) {
    let value = (cmd << 3) | (lowBits & 0x07);
    const bytes = [];

    do {
        let byte = value & 0x7F;
        value >>>= 7;

        if (value > 0) {
            byte |= 0x80;
        }

        bytes.push(byte);
    } while (value > 0);

    return Buffer.from(bytes);
};

function decode_cmd(buffer, offset) {
    const b0 = buffer[offset];
    const b1 = buffer[offset + 1];

    const value =
        (b0 & 0x7F) |
        ((b1 & 0x7F) << 7);

    return value >>> 3;
};

function decode32(buffer, offset = 0) {
    if (offset >= buffer.length) return null;

    const byte = buffer[offset];
    if (byte & 0x80) return null;

    return byte & 0x7F;
};

function get_private_key(key_name, key_len) {
    let privateKey;

    if (privateKey) {
        return privateKey;
    };

    const key_path = path.join('crypto', 'SSL', `${key_name}.pem`);

    privateKey = crypto.createPrivateKey(fs.readFileSync(key_path));

    if (privateKey.asymmetricKeyType !== 'rsa') {
        privateKey = null;
        return null;
    };

    const modulusLength = privateKey.asymmetricKeyDetails?.modulusLength;

    if (modulusLength !== key_len) {
        privateKey = null;
        return null;
    };

    return privateKey;
};

function decrypt_rsa(privateKey, data) {
    return crypto.privateDecrypt({
        key: privateKey,
        padding: crypto.constants.RSA_NO_PADDING
    }, data);
};

function generate_aes_key(x192) {
    if (!Buffer.isBuffer(x192) || x192.length !== 192) {
        return null;
    };

    const hash_0 = crypto.createHash('sha1').update(Buffer.alloc(4, 0)).update(x192).digest();
    const hash_1 = crypto.createHash('sha1').update(Buffer.from([0x00, 0x00, 0x00, 0x01])).update(x192).digest();

    return Buffer.concat([
        hash_0,
        hash_1.subarray(0, 12)
    ]);
};

function aes_ctr(aes_key, data, iv) {
    if (!Buffer.isBuffer(aes_key) || aes_key.length !== 32) {
        return null;
    };

    if (!Buffer.isBuffer(data)) {
        return null;
    };

    if (!Buffer.isBuffer(iv) || iv.length !== 16) {
        return null;
    };

    const cipher = crypto.createCipheriv(
        'aes-256-ctr',
        aes_key,
        iv
    );

    return Buffer.concat([
        cipher.update(data),
        cipher.final()
    ]);
};

function getAvatarByUsername(username) {
    if (typeof username !== 'string' || username.length === 0) return null;

    for (const ext of avatar_exts) {
        const file_path = path.join(avatar_dir, `${username}${ext}`);

        if (fs.existsSync(file_path)) {
            return file_path;
        };
    };
    
    return null;
};

module.exports = {
    calculate_seed,
    calculate_crc32,
    get_rc4_key,
    rc4,
    create_rc4_context,
    create_new_rc4_context,
    free_rc4_context,
    compute_md5_hash,
    encode_cmd,
    decode_cmd,
    decode32,
    get_private_key,
    decrypt_rsa,
    generate_aes_key,
    aes_ctr,
    getAvatarByUsername
};