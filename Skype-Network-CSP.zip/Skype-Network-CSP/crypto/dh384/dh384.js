const crypto = require('crypto');

function modPow(base, exp, mod) {
    let res = 1n;
    base = base % mod;

    while (exp > 0n) {
        if (exp & 1n) res = (res * base) % mod;
        exp >>= 1n;
        base = (base * base) % mod;
    };

    return res;
};

function generate_dh_keys() {
    const skype_prime_hex = 'FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B13B202FFFFFFFFFFFFFFFF';
    const p = BigInt('0x' + skype_prime_hex);
    const g = 2n;

    const privateKey = crypto.randomBytes(48);
    privateKey[0] &= 0x7f;
    const a = BigInt('0x' + privateKey.toString('hex'));

    const A = modPow(g, a, p);
    const publicKey = Buffer.from(A.toString(16).padStart(96, '0'), 'hex');

    const dh_mock = {
        computeSecret: (client_publicKey) => {
            if (!Buffer.isBuffer(client_publicKey) || client_publicKey.length !== 48) {
                throw new Error('DH-384 public key must be exactly 48 bytes');
            };

            const B = BigInt('0x' + client_publicKey.toString('hex'));
            if (B <= 1n || B >= p - 1n) {
                throw new Error('DH-384 public key is outside the accepted range');
            };

            const S = modPow(B, a, p);
            return Buffer.from(S.toString(16).padStart(96, '0'), 'hex');
        }
    };

    return {
        dh: dh_mock,
        publicKey: publicKey,
        privateKey: privateKey
    };
};

module.exports = {
    generate_dh_keys
};