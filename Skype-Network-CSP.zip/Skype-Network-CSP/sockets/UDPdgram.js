const functions = require('../functions/functions.js');
const logger = require("../logger/logger.js");

async function send(data, len, supernode, remote, client) {
    const time = functions.getTime();

    await new Promise((resolve, reject) => {
        supernode.send(data, 0, data.length, remote.port, remote.address, (error) => {
            if (error) { 
                reject(error);
            } else {
                logger.info(`${time} [supernode] sent ${len} bytes to ${client}: ${data.toString('hex')}`);
            };
        });
    });
};

module.exports = {
    send
};