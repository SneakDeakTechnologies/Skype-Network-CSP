const functions = require("../functions/functions.js");
const logger = require("../logger/logger.js");

function write(remote, socket, name, data) {
    const time = functions.getTime();

    socket.write(data);
    logger.info(`${time} [${name}] sent ${data.length} bytes to ${remote}: ${data.toString('hex')}`);
};

function destroy(socket) {
    socket.destroy();
};

function end(socket) {
    socket.end();
};

module.exports = {
    write,
    destroy,
    end
};