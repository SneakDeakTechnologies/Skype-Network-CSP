# SLOTINFO reply

The TCP Supernode now answers native SLOTINFO requests (command 0x06) with
SLOTINFO_REPLY (command 0x08).

The reply uses an EXT42 payload (0x42), one nested type 5 / id 6 record, and
echoes the request ID. The nested fields are:
- type 2 / id 3: advertised IPv4 address and TCP port
- type 0 / id 0: requested slot
- type 0 / id 7: 1 (one directory node returned)

## Advertised endpoint

The TCP listener still binds using `tcp_host` and `tcp_port`.

For a server behind NAT, configure these additional values in `config.env`:

```ini
tcp_public_ip=YOUR_PUBLIC_IPV4
tcp_public_port=YOUR_EXTERNAL_TCP_PORT
```

`tcp_public_port` may be omitted when the public port is the same as the
listener's local port. When these settings are absent, the server uses the
accepted socket's local IPv4 address and local TCP port; that fallback is
useful on a LAN but may be private behind NAT.

The handler accepts slot requests containing exactly fields 0/0 and 0/5,
with slot 0..2047 and requested count 1..32. Capability-pool requests that do
not contain 0/0 remain unsupported.

## Notes

The EXT42 packer declaration for `main_pack` now matches the DLL's three
argument ABI. The output buffer remains 0x50000 bytes, matching the DLL's
internal output capacity.
