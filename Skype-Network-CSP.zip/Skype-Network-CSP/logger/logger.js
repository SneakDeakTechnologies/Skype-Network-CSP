const chalk = require('chalk');

function info(message) {
    console.log(chalk.bold.cyan(message));
};

function warn(message) {
    console.log(chalk.bold.yellow(message));
};

function error(message) {
    console.log(chalk.bold.red(message));
};

module.exports = {
    info,
    warn,
    error
};