const skycrypto = require('./crypto/skycrypto.js');
const logger = require('./logger/logger.js');
const express = require('express');
const crypto = require('crypto');
const dotenv = require('dotenv');
const mysql = require('mysql2');
const https = require('https');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

dotenv.config({ 
    path: './config.env',
    quiet: true
});

const MySQL = mysql.createPool({
    host: process.env.mysql_host,
    user: process.env.mysql_user,
    password: process.env.mysql_password,
    database: process.env.mysql_database
});

MySQL.getConnection((error, connection) => {
    if (error) {
        throw new Error(`[MySQL] MySQL Connection Error: ${error}`);
    } else {
        logger.info(`\n[MySQL] Successful MySQL Connection`);
        connection.release();
    };
});

const options = {
    cert: fs.readFileSync(path.join(__dirname, 'crypto', 'SSL', 'api_cert.crt')),
    key: fs.readFileSync(path.join(__dirname, 'crypto', 'SSL', 'api_private.pem'))
};

const api = express();
const https_server = https.createServer(options, api);

api.use((req, res, next) => {
    logger.info(`\nURL: ${req.url}`);
    logger.info(`Method: ${req.method}`);
    logger.info(`From: ${req.ip}`);
    next();
});

api.use(cors());
api.use((req, res, next) => {
    if (
        req.method === 'POST' &&
        (
            req.path === '/contacts/v2/users/self/contacts' ||
            req.path === '/users/batch/profiles'
        ) &&
        !req.headers['content-type']
    ) {
        req.headers['content-type'] = 'application/json';
    };

    next();
});
api.use(express.json());
api.use(express.urlencoded({ extended: true }));
api.use(express.raw({ 
    type: ['image/png', 'image/jpeg', 'image/jpg', 'application/octet-stream'], 
    limit: '10mb' 
}));
api.use(express.static(path.join(__dirname, 'public')));

api.get('/users/:username/profile/avatar', (req, res) => {
    const { username } = req.params;

    try {
        const avatar_path = skycrypto.getAvatarByUsername(username);
        if (!avatar_path) return res.status(404).end();

        return res.sendFile(avatar_path);
    } catch (error) {
        return res.status(500).end();
    };
});

const api_config = {
    host: process.env.api_host,
    port: parseInt(process.env.api_port)
};

https_server.listen(api_config.port, api_config.host, () => {
    process.title = 'Skype API Server';
    logger.info(`Skype API Server is running on: https://${api_config.host}:${api_config.port}`);
    logger.info(`Waiting for connections...`);
});