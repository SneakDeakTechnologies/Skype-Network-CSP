/*
    * @file Skype TCP SuperNode
    * @author Nikita Konev nikitakonev892@gmail.com
    * @copyright SneakDeak Technologies 2026
*/
const skyobjects = require('./proto/objects/skyobjects.js');
const skyparser = require('./proto/parser/skyparser.js');
const functions = require('./functions/functions.js');
const builder = require('./proto/builder/builder.js');
const TCPsocket = require('./sockets/TCPsocket.js');
const skycrypto = require('./crypto/skycrypto.js');
const common = require('./proto/common/common.js');
const varint = require('./proto/utils/varint.js');
const dh384 = require('./crypto/dh384/dh384.js');
const logger = require('./logger/logger.js');
const crypto = require('crypto');
const dotenv = require('dotenv');
const mysql = require('mysql2');
const net = require('net');
const fs = require('fs');

dotenv.config({ 
    path: './config.env',
    quiet: true
});

const MySQL = mysql.createPool({
    host: process.env.mysql_host,
    user: process.env.mysql_user,
    password: process.env.mysql_password,
    database: process.env.mysql_database
});

MySQL.getConnection((error, connection) => {
    if (error) {
        throw new Error(`[MySQL] MySQL Connection Error: ${error}`);
    } else {
        logger.info(`[MySQL] Successful MySQL Connection\n`);
        connection.release();
    };
});

const clients = new Map();
let credentials_private_key = null;

function get_credentials_private_key() {
    if (credentials_private_key === null) {
        credentials_private_key = fs.readFileSync('crypto/SSL/private_2048.pem');
    };
    
    return credentials_private_key;
};

function process_client_accept(buffer, remote, socket, client, time) {
    if (buffer.length < 9) {
        return false;
    };

    const packet_size = 6 + buffer[3];

    if (buffer.length < packet_size) {
        return false;
    };

    const packetType = buffer[0];
    const seq = buffer.readUInt16BE(1);
    const cmd = skycrypto.decode_cmd(buffer, 4);
    const requestId = buffer.readUInt16BE(6);
    const paramListType = buffer[8];
    const objects = buffer.subarray(8);
    
    logger.info(`${time} [supernode] packetType=${packetType.toString(16)} seq=${seq.toString(16)} cmd=$${cmd.toString(10)} requestId=${requestId.toString(16)} paramListType=${paramListType.toString(16)} objects=${objects.toString('hex')}`);

    switch (cmd) {
        case common.CMD_CLIENT:
            if (paramListType.toString(16) === common.EXT_PARAMS.toString(16)) {
                const decoded = skyobjects.unpack_ext_objects(objects);
                logger.info(`${time} [supernode] decoded objects:`);

                const obj = skyobjects.parse_ext_objects(decoded);
                client.connected = true;

                const tcp_accept = builder.build_tcp_accept(seq, requestId, socket, client.send_rc4);

                if (!tcp_accept || tcp_accept.length === 0) {
                    return false;
                };
                
                TCPsocket.write(remote, socket, "supernode", tcp_accept);

                client.state = "SLOTINFO";
                client.node_buffer = Buffer.alloc(0);
                
                return true;
            } else {
                return false;
            };
        break;
    };
};

function process_slotinfo(client, time) {
    const MAX_FRAME_SIZE = 16384;

    if (!Buffer.isBuffer(client.node_buffer)) {
        client.node_buffer = Buffer.alloc(0);
    };

    while (client.node_buffer.length > 0) {
        let frame_header;

        try {
            frame_header = varint.read_7bit_uint(
                client.node_buffer,
                0
            );
        } catch (error) {
            if (error instanceof RangeError && error.message === 'Incomplete 7-bit uint') {
                return; 
            };

            throw error;
        };

        const encoded_length = frame_header.value;
        const frame_length = Math.floor(encoded_length / 2);
        const header_length = frame_header.offset;

        if (frame_length <= 0 || frame_length > MAX_FRAME_SIZE) {
            throw new Error(`Invalid Node frame length: ${frame_length}`);
        };

        const total_length = header_length + frame_length;

        if (client.node_buffer.length < total_length) {
            return;
        };

        const frame = client.node_buffer.subarray(
            header_length,
            total_length
        );

        client.node_buffer = client.node_buffer.subarray(total_length);

        if (encoded_length & 1) {
            if (frame.length !== 3 || frame[0] !== 0x01) {
                throw new Error('Invalid Node ACK');
            };

            const seq = frame.readUInt16BE(1);
            continue;
        };

        if (frame.length < 2) {
            throw new Error('Node frame does not contain sequence');
        };

        const seq = frame.readUInt16BE(0);
        let offset = 2;

        while (offset < frame.length) {
            const body_length = varint.read_7bit_uint(frame, offset);

            offset = body_length.offset;
            const encoded_cmd = varint.read_7bit_uint(frame, offset);

            offset = encoded_cmd.offset;

            const cmd = encoded_cmd.value >>> 3;
            const flags = encoded_cmd.value & 0x07;

            if (flags > 3) {
                throw new Error(`Invalid Node flags: ${flags}`);
            };

            const cmd_end = offset + body_length.value;

            if (cmd_end > frame.length) {
                throw new Error('Node command exceeds frame boundary');
            };

            let requestId = null;

            if (flags === 2 || flags === 3) {
                if (offset + 2 > cmd_end) {
                    throw new Error('Missing Node requestId');
                };

                requestId = frame.readUInt16BE(offset);
                offset += 2;
            };

            const payload = frame.subarray(offset, cmd_end);

            if (payload.length === 0) {
                throw new Error('Empty Node command payload');
            };

            offset = cmd_end;
            logger.info(`${time} [supernode] seq=0x${seq.toString(16)} cmd=0x${cmd.toString(16)} flags=${flags} requestId=${requestId === null ? 'none' : '0x' + requestId.toString(16)} payload=${payload.toString('hex')}`);

            if (payload[0] === common.EXT_PARAMS) {
                switch (cmd) {
                    case common.CMD_SLOTINFO:
                        const decoded = skyobjects.unpack_ext_objects(
                            payload,
                            { allow_partial: true }
                        );
                        
                        if (!decoded) {
                            continue;
                        };

                        const objects = skyobjects.parse_ext_objects(decoded);
                        
                        const slot_object = objects?.find(object => object.type === 0 && object.id === 0);
                        const count_object = objects?.find(object => object.type === 0 && object.id === 5);

                        if (!slot_object || !count_object) {
                            logger.warn(`${time} [supernode] SLOTINFO request is missing 0/0 slot or 0/5 count`);
                            continue;
                        };

                        const slot = slot_object.m;
                        const requested_count = count_object.m;

                        logger.info(`${time} [supernode] slot=${slot.toString(16)} count=${requested_count}`);
                    break;
                };
            };
        };
    };
};

const supernode =  net.createServer((socket) => {
    const remote = `${socket.remoteAddress}:${socket.remotePort}`;
    const time = functions.getTime();
    
    logger.info(`${time} [supernode] work with client: ${remote}`);

    clients.set(socket, {
        state: "HANDSHAKE",
        shared_secret: null,
        recv_rc4: null,
        send_rc4: null,
        connected: false,
        node_buffer: Buffer.alloc(0),
        login_buffer: Buffer.alloc(0),
        login_pending_records: [],
        login_aes_key: null,
        login_record_index: 0
    });
    
    socket.on('data', (data) => {
        const client = clients.get(socket);
        const hex = data.toString('hex');

        const time = functions.getTime();
        logger.info(`${time} [supernode] received ${data.length} bytes from ${remote}: ${hex}`);

        if (client.state === "HANDSHAKE") {
            if (data.length === 14) {
                const iv = data.readUInt32BE(0);
                logger.info(`${time} [supernode] iv=0x${iv.toString(16)}`);

                const body = Buffer.from(data.subarray(4));
                client.recv_rc4 = skycrypto.create_rc4_context(iv);
                
                skycrypto.rc4(body, client.recv_rc4, true);
                logger.info(`${time} [supernode] decrypted body: ${body.toString('hex')}`);

                const packetType = body[9];
                
                switch (packetType) {
                    case common.PKT_TYPE_CTRL:
                        const send_iv = crypto.randomBytes(4).readUInt32BE(0);
                        client.send_rc4 = skycrypto.create_rc4_context(send_iv);
                        
                        const tcp_handshake = builder.build_tcp_handshake(send_iv, client.send_rc4);
                        
                        if (!tcp_handshake) {
                            TCPsocket.end(socket);
                            clients.delete(socket);
                        };

                        TCPsocket.write(remote, socket, "supernode", tcp_handshake);
                        client.state = "ACCEPT";
                    break;
                };
            } else if (data.length >= 48) {
                const client_publicKey = data.subarray(0, 48);
                const supernode_dh384 = dh384.generate_dh_keys();

                const shared_secret = supernode_dh384.dh.computeSecret(client_publicKey);
                const supernode_publicKey = supernode_dh384.publicKey;

                client.shared_secret = Buffer.from(shared_secret);
                TCPsocket.write(remote, socket, "supernode", supernode_publicKey);

                client.state = "MD5_HANDSHAKE";
            } else if (data[0] === 0x16 && data[1] == 0x03 && data[2] === 0x01 && data.length === 5) {
                const tls_handshake = Buffer.from([0x17, 0x03, 0x01, 0x00, 0x00]);
                TCPsocket.write(remote, socket, "supernode", tls_handshake);
                
                client.state = "LOGIN";
            };
        } else if (client.state === "ACCEPT") {
            const decrypted = Buffer.from(data);
            skycrypto.rc4(decrypted.subarray(0, 3), client.recv_rc4, false);

            skycrypto.rc4(decrypted.subarray(3), client.recv_rc4, false);
            logger.info(`${time} [supernode] decrypted packet: ${decrypted.toString('hex')}`);

            if (!process_client_accept(decrypted, remote, socket, client, time)) {
                TCPsocket.end(socket);
                return;
            };
        } else if (client.state === "MD5_HANDSHAKE" && client.shared_secret) {
            const received = data.subarray(0, 8);
            const computed = skycrypto.compute_md5_hash("O", client.shared_secret);

            logger.info(`${time} [supernode] computed=${computed.toString('hex')} received=${received.toString('hex')}`);

            if (received.length !== 8 ||computed.length !== 8 ||!crypto.timingSafeEqual(received, computed)) {
                logger.info(`${time} [supernode] md5 mismatch!`);
                TCPsocket.end(socket);
                return;
            };

            const md5_I = skycrypto.compute_md5_hash("I", client.shared_secret);
            TCPsocket.write(remote, socket, "supernode", md5_I);

            const send_iv = crypto.randomBytes(4).readUInt32BE(0);
            client.send_rc4 = skycrypto.create_new_rc4_context(send_iv, client.shared_secret);
            
            const tcp_handshake = builder.build_new_tcp_handshake(send_iv, client.send_rc4);
            TCPsocket.write(remote, socket, "supernode", tcp_handshake);

            client.state = "RC4_HANDSHAKE";
        } else if (client.state === "RC4_HANDSHAKE" && client.send_rc4 && !client.recv_rc4) {
            const iv = data.readUInt32BE(0);
            const header = Buffer.from(data.subarray(4, 14));

            logger.info(`${time} [supernode] iv=0x${iv.toString(16)}`);
            client.recv_rc4 = skycrypto.create_new_rc4_context(iv, client.shared_secret);

            skycrypto.rc4(header, client.recv_rc4, true);
            logger.info(`${time} [supernode] decrypted header: ${header.toString('hex')}`);

            const body = Buffer.from(data.subarray(14));
            skycrypto.rc4(body, client.recv_rc4, false);

            logger.info(`${time} [supernode] decrypted body: ${body.toString('hex')}`);

            const decoded_len = skycrypto.decode32(body, 0);
            const skip_bytes = 1 + Math.floor(decoded_len / 2);

            const client_data = body.subarray(skip_bytes);

            if (client_data.length === 0) {
                client.state = "ACCEPT";
                return;
            } else if (client_data.length >= 6) {
                if (!process_client_accept(client_data, remote, socket, client, time)) {
                    TCPsocket.end(socket);
                    return;
                };
            };
        } else if (client.state === "SLOTINFO" && client.recv_rc4 && client.send_rc4) {
            const decrypted = Buffer.from(data);
            skycrypto.rc4(decrypted, client.recv_rc4, false);

            logger.info(`${time} [supernode] decrypted packet: ${decrypted.toString('hex')}`);

            client.node_buffer = Buffer.concat([
                client.node_buffer,
                decrypted
            ]);

            try {
                process_slotinfo(client, time);
            } catch (error) {
                logger.error(`${time} [supernode] SLOTINFO parser error: ${error.message}`);

                TCPsocket.destroy(socket);
                return;
            };
        } else if (client.state === "LOGIN") {
            client.login_buffer = Buffer.concat([
                client.login_buffer ?? Buffer.alloc(0),
                data
            ]);

            while (client.login_buffer.length >= 5) {
                const pending = client.login_buffer;

                const recordType = pending[0];
                const versionMajor = pending[1];
                const versionMinor = pending[2];
                const payloadLength = pending.readUInt16BE(3);
                const totalLength = 5 + payloadLength;

                if (versionMajor !== 0x03 || versionMinor !== 0x01) {
                    logger.warn(`${time} [supernode] invalid LOGIN record version`);

                    TCPsocket.destroy(socket);
                    return;
                };

                if (pending.length < totalLength) {
                    return;
                };

                const record = Buffer.from(
                    pending.subarray(0, totalLength)
                );

                client.login_buffer = Buffer.from(
                    pending.subarray(totalLength)
                );

                if (recordType === 0x16 && payloadLength === 0) {
                    const reply = Buffer.from([
                        0x17, 0x03, 0x01, 0x00, 0x00
                    ]);

                    TCPsocket.write(remote, socket, "supernode", reply);
                    continue;
                };

                if (recordType === 0x16) {
                    if (client.login_pending_records.length === 0) {
                        if (Buffer.isBuffer(client.login_aes_key)) {
                            client.login_aes_key.fill(0);
                        };
                        client.login_aes_key = null;
                        client.login_record_index = 0;
                    };

                    client.login_pending_records.push(record);
                    continue;
                };

                if (recordType === 0x17) {
                    let parsed_records;

                    const has_handshake = client.login_pending_records.some(
                        (item) => item[0] === 0x16
                    );

                    if (has_handshake) {
                        // First ApplicationData record after the key exchange:
                        // derive AES once, then retain it for later 0x17 records.
                        const auth_packet = Buffer.concat([
                            ...client.login_pending_records,
                            record
                        ]);

                        client.login_pending_records = [];
                        parsed_records = skyparser.parse_tls_packet(auth_packet);

                        if (
                            !parsed_records.ok ||
                            !Buffer.isBuffer(parsed_records.aes_key) ||
                            parsed_records.aes_key.length !== 32 ||
                            parsed_records.incomplete ||
                            !Array.isArray(parsed_records.packets) ||
                            parsed_records.packets.length === 0
                        ) {
                            logger.warn(`${time} [supernode] LOGIN key exchange/application record parse failed: ${parsed_records.error || 'incomplete or empty handshake data'}`);
                            TCPsocket.end(socket);
                            return;
                        };

                        if (Buffer.isBuffer(client.login_aes_key)) {
                            client.login_aes_key.fill(0);
                        };
                        client.login_aes_key = Buffer.from(parsed_records.aes_key);
                        client.login_record_index = parsed_records.nextRecordIndex;
                    } else {
                        if (!Buffer.isBuffer(client.login_aes_key) || client.login_aes_key.length !== 32) {
                            continue;
                        };

                        parsed_records = skyparser.parse_tls_records(
                            client.login_aes_key,
                            record,
                            client.login_record_index
                        );

                        if (!parsed_records.ok || parsed_records.incomplete || parsed_records.consumed !== record.length) {
                            logger.warn(`${time} [supernode] LOGIN ApplicationData parse failed at record index ${client.login_record_index}: ${parsed_records.error || 'incomplete TLS record'}`);
                            TCPsocket.end(socket);
                            return;
                        };

                        client.login_record_index = parsed_records.nextRecordIndex;
                    };

                    const aes_key = client.login_aes_key;

                    for (const parsed_packet of parsed_records.packets) {
                        const blob = parsed_packet.blob;
                        if (!blob) {
                            logger.warn(`${time} [supernode] LOGIN decrypted record did not contain a valid account blob`);
                            continue;
                        };

                        const username = blob.username;
                        const password = blob.password;
                        const clientModulus = blob.publicKey;
                        const cmd = blob.cmd;

                        switch (cmd) {
                            case common.LOGIN_REQ:
                            case 5017:
                                MySQL.query(
                                    'SELECT password FROM skype_users WHERE username = ?',
                                    [username],
                                    (error, users) => {
                                        if (error) {
                                            logger.error(`${time} [MySQL] Login lookup failed: ${error.message}`);
                                            TCPsocket.end(socket);
                                            return;
                                        };

                                        if (!users || users.length === 0) {
                                            const auth_fail = builder.build_auth_answer(
                                                common.LOGIN_FAIL,
                                                blob.requestId,
                                                aes_key
                                            );

                                            TCPsocket.write(remote, socket, "supernode", auth_fail);
                                            TCPsocket.end(socket);
                                            return;
                                        };

                                        const user = users[0];

                                        if (password !== user.password) {
                                            const auth_fail = builder.build_auth_answer(
                                                common.LOGIN_FAIL,
                                                blob.requestId,
                                                aes_key
                                            );

                                            TCPsocket.write(remote, socket, "supernode", auth_fail);
                                            TCPsocket.end(socket);
                                            return;
                                        };

                                        const uic = builder.generate_uic(
                                            username,
                                            clientModulus,
                                            get_credentials_private_key(),
                                            0x0BBBD6F1,
                                            0x0BD99AF1,
                                            1
                                        );

                                        const auth_ok = builder.build_auth_answer(
                                            common.LOGIN_OK,
                                            blob.requestId,
                                            aes_key,
                                            uic
                                        );

                                        TCPsocket.write(remote, socket, "supernode", auth_ok);
                                    }
                                );
                            break;

                            case common.ACCOUNT_EMAIL_REQ:
                                MySQL.query(
                                    'SELECT password, email FROM skype_users WHERE username = ?',
                                    [username],
                                    (error, users) => {
                                        if (error) {
                                            logger.error(`${time} [MySQL] Account email lookup failed: ${error.message}`);
                                            TCPsocket.end(socket);
                                            return;
                                        };

                                        if (!users || users.length === 0) {
                                            const auth_fail = builder.build_auth_answer(
                                                common.LOGIN_FAIL,
                                                blob.requestId,
                                                aes_key
                                            );

                                            TCPsocket.write(remote, socket, "supernode", auth_fail);
                                            TCPsocket.end(socket);
                                            return;
                                        };

                                        const user = users[0];

                                        if (password !== user.password) {
                                            const auth_fail = builder.build_auth_answer(
                                                common.LOGIN_FAIL,
                                                blob.requestId,
                                                aes_key
                                            );

                                            TCPsocket.write(remote, socket, "supernode", auth_fail);
                                            TCPsocket.end(socket);
                                            return;
                                        };

                                        const account_email = builder.build_account_email(
                                            blob.requestId,
                                            aes_key,
                                            user.email || ''
                                        );

                                        TCPsocket.write(remote, socket, "supernode", account_email);
                                    }
                                );
                            break;

                            default:
                                logger.warn(`${time} [supernode] unknown cmd: ${cmd}`);
                            break;
                        };
                    };
                };
            };
        } else {
            TCPsocket.end(socket);
        };
    });

    socket.on('close', () => {
        const time = functions.getTime();
        logger.info(`${time} [supernode] client ${remote} disconnected`);

        const client = clients.get(socket);

        if (client) {
            client.connected = false;

            if (Buffer.isBuffer(client.login_aes_key)) {
                client.login_aes_key.fill(0);
                client.login_aes_key = null;
            };

            if (client.recv_rc4) {
                skycrypto.free_rc4_context?.(client.recv_rc4);
            };

            if (client.send_rc4) {
                skycrypto.free_rc4_context?.(client.send_rc4);
            };
        };

        clients.delete(socket);
    });
    
    socket.on('error', (error) => {
        const time = functions.getTime();
        
        logger.error(`${time} [supernode] client ${remote} error : ${error.message}`);
        socket.destroy();
    });
});

const tcp_config = {
    host: process.env.tcp_host,
    port: process.env.tcp_port
};

supernode.listen(tcp_config.port, tcp_config.host, () => {
    process.stdout.write('\x1B]0;Skype TCP SuperNode\x07');

    logger.info(`Skype TCP SuperNode listening on: tcp://${tcp_config.host}:${tcp_config.port}`);
    logger.info(`Waiting for connections...\n`);
});