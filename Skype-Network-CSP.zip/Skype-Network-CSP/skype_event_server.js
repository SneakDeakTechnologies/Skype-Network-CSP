/*
    * @file Skype Event Server
    * @author Nikita Konev nikitakonev892@gmail.com
    * @copyright SneakDeak Technologies 2026
*/
const skyobjects = require('./proto/objects/skyobjects.js');
const skyparser = require('./proto/parser/skyparser.js');
const documents = require('./proto/utils/documents.js');
const functions = require('./functions/functions.js');
const builder = require('./proto/builder/builder.js');
const TCPsocket = require('./sockets/TCPsocket.js');
const skycrypto = require('./crypto/skycrypto.js');
const common = require('./proto/common/common.js');
const logger = require('./logger/logger.js');
const crypto = require('crypto');
const dotenv = require('dotenv');
const mysql = require('mysql2');
const net = require('net');
const fs = require('fs');

dotenv.config({ 
    path: './config.env',
    quiet: true
});

const MySQL = mysql.createPool({
    host: process.env.mysql_host,
    user: process.env.mysql_user,
    password: process.env.mysql_password,
    database: process.env.mysql_database
});

MySQL.getConnection((error, connection) => {
    if (error) {
        throw new Error(`[MySQL] MySQL Connection Error: ${error}`);
    } else {
        logger.info(`[MySQL] Successful MySQL Connection\n`);
        connection.release();
    };
});

const clients = new Map();

const event =  net.createServer((socket) => {
    const remote = `${socket.remoteAddress}:${socket.remotePort}`;
    const time = functions.getTime();
    
    logger.info(`${time} [event] work with client: ${remote}`);

    clients.set(socket, {
        state: "HANDSHAKE",
        packet_buffer: Buffer.alloc(0)
    });
    
    socket.on('data', (data) => {
        const client = clients.get(socket);
        const hex = data.toString('hex');

        const time = functions.getTime();
        logger.info(`${time} [event] received ${data.length} bytes from ${remote}: ${hex}`);

        if (client.state === "HANDSHAKE") {
            if (data[0] === 0x16 && data[1] === 0x03 && data[2] === 0x01 && data[3] === 0x00 && data[4] === 0x00) {
                const tls_handshake = Buffer.from([0x17, 0x03, 0x01, 0x00, 0x00]);
                TCPsocket.write(remote, socket, "event", tls_handshake);

                client.state = "READY";
            };
        } else if (client.state === "READY") {
            client.packet_buffer = Buffer.concat([
                client.packet_buffer,
                data
            ]);

            if (client.packet_buffer.length < 5) {
                return;
            };

            const buffer = client.packet_buffer;
            const first_is_empty =
                buffer[0] === 0x16 &&
                buffer[1] === 0x03 &&
                buffer[2] === 0x01 &&
                buffer.readUInt16BE(3) === 0;

            if (first_is_empty) {
                if (buffer.length < 10) {
                    return;
                };

                const next_is_handshake =
                    buffer[5] === 0x16 &&
                    buffer[6] === 0x03 &&
                    buffer[7] === 0x01;

                if (next_is_handshake) {
                    const next_length = buffer.readUInt16BE(8);
                    client.packet_buffer = buffer.subarray(5);
                };
            };

            const parsed_tls_packet = skyparser.parse_tls_packet(client.packet_buffer);

            if (!parsed_tls_packet.ok) {
                TCPsocket.end(socket);
                return;
            };

            const aes_key = parsed_tls_packet.aes_key;
            const blobs = (parsed_tls_packet.packets || [])
                .map(packet => packet.blob)
                .filter(Boolean);

            if (!aes_key || blobs.length === 0) {
                return;
            };

            const username = blobs[0].username;
            const password = blobs[0].password;

            MySQL.query(
                'SELECT * FROM skype_users WHERE username = ?',
                [username],
                (error, users) => {
                    if (error) {
                        logger.error(`${time} [MySQL] Login lookup failed: ${error.message}`);
                        TCPsocket.end(socket);
                        return;
                    };

                    if (!users || users.length === 0) {
                        const auth_fail = builder.build_auth_answer(
                            common.LOGIN_FAIL,
                            blobs[0].requestId,
                            aes_key
                        );

                        if (auth_fail) {
                            TCPsocket.write(remote, socket, "event", auth_fail);
                        };
                        TCPsocket.end(socket);
                        return;
                    };

                    const user = users[0];

                    if (password !== user.password) {
                        const auth_fail = builder.build_auth_answer(
                            common.LOGIN_FAIL,
                            blobs[0].requestId,
                            aes_key
                        );

                        if (auth_fail) {
                            TCPsocket.write(remote, socket, "event", auth_fail);
                        };
                        TCPsocket.end(socket);
                        return;
                    };

                    (async () => {
                        for (const blob of blobs) {
                            const cmd = blob.cmd;
                            const requestId = blob.requestId;

                            switch (cmd) {
                                case common.CONTACT_LIST_INDX_REQ: {
                                    const contact_list_indx = builder.build_contact_list_index(
                                        true,
                                        blob.requestId,
                                        aes_key
                                    );

                                    if (!contact_list_indx) {
                                        TCPsocket.end(socket);
                                        return;
                                    };

                                    TCPsocket.write(remote, socket, "event", contact_list_indx);
                                    break;
                                };

                                case common.NATIVE_DOC_MANIFEST_REFRESH_REQ:
                                case common.NATIVE_DOC_MANIFEST_REQ: {
                                    const [contacts] = await MySQL.promise().query(
                                        `SELECT contact, fullName
                                        FROM skype_contacts
                                        WHERE owner = ? AND listId = 1
                                        ORDER BY sort_order, created_at`,
                                        [username]
                                    );

                                    const account_profile = {
                                        fullName: user.fullName,
                                        birthday: user.birthday,
                                        sex: user.sex,
                                        province: user.province,
                                        city: user.city,
                                        homepage: user.homepage,
                                        about: user.about,
                                        profile_timestamp: 0
                                    };

                                    const generated_documents = builder.build_native_documents(
                                        contacts,
                                        account_profile,
                                        username
                                    );

                                    if (!generated_documents) {
                                        TCPsocket.end(socket);
                                        return;
                                    };

                                    const snapshot = await documents.seed_and_read(
                                        MySQL,
                                        username,
                                        generated_documents
                                    );

                                    const doc_manifest = builder.build_doc_manifest(
                                        requestId,
                                        aes_key,
                                        snapshot.documents,
                                        snapshot.revision
                                    );

                                    if (!doc_manifest) {
                                        TCPsocket.end(socket);
                                        return;
                                    };

                                    client.native_documents = snapshot.documents;
                                    client.native_document_revision = snapshot.revision;

                                    TCPsocket.write(remote, socket, "event", doc_manifest.packet);
                                    break;
                                };

                                case common.CONTACT_LIST_REQ:
                                    MySQL.query(
                                        'SELECT * FROM skype_contacts WHERE owner = ?',
                                        [username],
                                        (error, contacts) => {
                                            if (error) {
                                                TCPsocket.end(socket);
                                                return;
                                            };

                                            const contact_list = builder.build_contact_list(
                                                requestId,
                                                aes_key,
                                                contacts
                                            );

                                            if (!contact_list) {
                                                TCPsocket.end(socket);
                                                return;
                                            };

                                            TCPsocket.write(remote, socket, "event", contact_list);
                                        }
                                    );
                                break;
                                    
                                case common.NATIVE_DOC_GET_REQ: {
                                    const checksum_field = blob.metadata.find(
                                        field => field.type === 0 && field.id === 0x32
                                    );

                                    const instance_field = blob.metadata.find(
                                        field => field.type === 1 && field.id === 0x3A
                                    );

                                    if (!checksum_field || !Number.isInteger(checksum_field.value)) {
                                        break;
                                    };

                                    if (!instance_field || !Buffer.isBuffer(instance_field.value) || instance_field.value.length !== 8) {
                                        break;
                                    };

                                    const checksum = checksum_field.value >>> 0;
                                    const document = client.native_documents?.get(checksum);

                                    if (!document) {
                                        break;
                                    };

                                    const native_document = builder.build_native_document(
                                        requestId,
                                        aes_key,
                                        client.native_document_revision || 0,
                                        document.name,
                                        document.body
                                    );

                                    if (!native_document) {
                                        TCPsocket.end(socket);
                                        return;
                                    };

                                    logger.info(`${time} [event] Central Storage GET owner=${username} name=${document.name}`);
                                    TCPsocket.write(remote, socket, "event", native_document);
                                    break;
                                };

                                case common.NATIVE_DOC_PUT_REQ: {
                                    const checksum_field = blob.metadata.find(
                                        field => field.type === 0 && field.id === 0x32
                                    );

                                    const instance_field = blob.metadata.find(
                                        field => field.type === 1 && field.id === 0x3A
                                    );

                                    const name_field = blob.metadata.find(
                                        field => field.type === 3 && field.id === 0x34
                                    );

                                    const body_field = blob.metadata.find(
                                        field => field.type === 4 && field.id === 0x33
                                    );

                                    if (!checksum_field || !Number.isInteger(checksum_field.value) || !instance_field || !Buffer.isBuffer(instance_field.value) || instance_field.value.length !== 8 || !name_field || typeof name_field.value !== 'string' || !body_field || !Buffer.isBuffer(body_field.value)) {
                                        break;
                                    };

                                    const checksum = checksum_field.value >>> 0;
                                    const name = name_field.value;
                                    const body = body_field.value;
                                    const stored = await documents.put_document(
                                        MySQL,
                                        username,
                                        name,
                                        body,
                                        checksum
                                    );

                                    if (!stored) {
                                        logger.warn(`${time} [event] Central Storage PUT rejected owner=${username} name=${name}`);
                                        break;
                                    };

                                    if (!client.native_documents) {
                                        client.native_documents = new Map();
                                    };

                                    for (const [document_checksum, document] of client.native_documents) {
                                        if (document.name === name || document_checksum === checksum) {
                                            client.native_documents.delete(document_checksum);
                                        };
                                    };

                                    client.native_documents.set(checksum, {
                                        name,
                                        body,
                                        checksum
                                    });
                                    client.native_document_revision = stored.revision;

                                    const native_document_ack = builder.build_native_document_ack(
                                        requestId,
                                        aes_key,
                                        stored.revision
                                    );

                                    if (!native_document_ack) {
                                        TCPsocket.end(socket);
                                        return;
                                    };

                                    TCPsocket.write(remote, socket, "event", native_document_ack);
                                    break;
                                };

                                default: 
                                    logger.warn(`${time} [event] unknown cmd: ${cmd}`);
                                break;
                            };
                        };
                    })().catch(error => {
                        logger.error(`${time} [event] cmd processing failed: ${error.message}`);
                        TCPsocket.end(socket);
                    });
                }
            );
        };
    });

    socket.on('close', () => {
        const time = functions.getTime();
        logger.info(`${time} [event] client ${remote} disconnected`);

        const client = clients.get(socket);
        if (client) {
            if (client.recv_rc4) skycrypto.free_rc4_context?.(client.recv_rc4);
            if (client.send_rc4) skycrypto.free_rc4_context?.(client.send_rc4);
        };
        clients.delete(socket);
    });
    
    socket.on('error', (error) => {
        const time = functions.getTime();
        
        logger.error(`${time} [event] client ${remote} error : ${error.message}`);
        socket.destroy();
    });
});

const event_config = {
    host: process.env.event_host,
    port: process.env.event_port
};

event.listen(event_config.port, event_config.host, () => {
    process.stdout.write('\x1B]0;Skype Event Server\x07');

    logger.info(`Skype Event Server listening on: tcp://${event_config.host}:${event_config.port}`);
    logger.info(`Waiting for connections...\n`);
});